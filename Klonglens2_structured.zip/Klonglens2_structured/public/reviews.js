// Reviews System for Klonglens
class ReviewsSystem {
    constructor() {
        this.currentRating = 0;
        this.currentProduct = null;
        this.init();
    }
    
    init() {
        this.bindEvents();
    }
    
    bindEvents() {
        // Review modal controls
        const reviewModal = document.getElementById('review-modal');
        const closeReview = document.getElementById('close-review');
        const cancelReview = document.getElementById('cancel-review');
        const reviewForm = document.getElementById('review-form');
        
        if (closeReview) {
            closeReview.addEventListener('click', () => this.closeReviewModal());
        }
        
        if (cancelReview) {
            cancelReview.addEventListener('click', () => this.closeReviewModal());
        }
        
        if (reviewForm) {
            reviewForm.addEventListener('submit', (e) => this.handleReviewSubmit(e));
        }
        
        // Rating stars
        document.querySelectorAll('#rating-input .star').forEach(star => {
            star.addEventListener('click', (e) => {
                const rating = parseInt(e.target.dataset.rating);
                this.setRating(rating);
            });
            
            star.addEventListener('mouseenter', (e) => {
                const rating = parseInt(e.target.dataset.rating);
                this.highlightStars(rating);
            });
        });
        
        const ratingInput = document.getElementById('rating-input');
        if (ratingInput) {
            ratingInput.addEventListener('mouseleave', () => {
                this.highlightStars(this.currentRating);
            });
        }
        
        // Click outside modal to close
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeReviewModal();
            }
        });
    }
    
    openReviewModal(product) {
        this.currentProduct = product;
        this.currentRating = 0;
        
        const modal = document.getElementById('review-modal');
        if (modal) {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // Reset form
        const form = document.getElementById('review-form');
        if (form) {
            form.reset();
        }
        
        // Reset rating
        this.setRating(0);
    }
    
    closeReviewModal() {
        const modal = document.getElementById('review-modal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        this.currentProduct = null;
        this.currentRating = 0;
    }
    
    setRating(rating) {
        this.currentRating = rating;
        
        // Update hidden input
        const ratingValue = document.getElementById('rating-value');
        if (ratingValue) {
            ratingValue.value = rating;
        }
        
        // Update star display
        this.highlightStars(rating);
    }
    
    highlightStars(rating) {
        document.querySelectorAll('#rating-input .star').forEach((star, index) => {
            const starRating = index + 1;
            if (starRating <= rating) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
    }
    
    async handleReviewSubmit(e) {
        e.preventDefault();
        
        if (!this.currentProduct) {
            this.showError('ไม่พบข้อมูลสินค้า');
            return;
        }
        
        if (this.currentRating === 0) {
            this.showError('กรุณาให้คะแนน');
            return;
        }
        
        const title = document.getElementById('review-title')?.value.trim() || '';
        const reviewText = document.getElementById('review-text')?.value.trim();
        
        if (!reviewText) {
            this.showError('กรุณาเขียนรีวิว');
            return;
        }
        
        // ตรวจสอบการเข้าสู่ระบบ
        const isLoggedIn = this.checkLoginStatus();
        if (!isLoggedIn) {
            if (confirm('กรุณาเข้าสู่ระบบก่อนเขียนรีวิว\nต้องการไปหน้าเข้าสู่ระบบหรือไม่?')) {
                window.location.href = 'login.html';
            }
            return;
        }
        
        try {
            // แสดงการโหลด
            const submitBtn = e.target.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'กำลังส่ง...';
            
            const reviewData = {
                productId: this.currentProduct.id,
                rating: this.currentRating,
                title: title,
                reviewText: reviewText,
                userId: 'demo-user', // จำลองข้อมูลผู้ใช้
                userName: 'ผู้ใช้งาน'
            };
            
            // จำลองการส่งข้อมูล
            await this.submitReview(reviewData);
            
            // แสดงความสำเร็จ
            this.showSuccess('ส่งรีวิวเรียบร้อยแล้ว! ขอบคุณสำหรับความคิดเห็น');
            
            // ปิด modal
            this.closeReviewModal();
            
            // อัปเดตการแสดงผล
            if (window.productDetail) {
                window.productDetail.loadProductReviews(this.currentProduct.id);
            }
            
            // รีเซ็ตปุ่ม
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
            
        } catch (error) {
            console.error('Review error:', error);
            this.showError('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
        }
    }
    
    async submitReview(reviewData) {
        // จำลองการส่งข้อมูลไปยัง API
        return new Promise((resolve) => {
            setTimeout(() => {
                // บันทึกลง localStorage สำหรับการทดสอบ
                const reviews = JSON.parse(localStorage.getItem('klonglens_reviews') || '[]');
                const newReview = {
                    id: Date.now(),
                    ...reviewData,
                    status: 'approved', // จำลองการอนุมัติอัตโนมัติ
                    createdAt: new Date().toISOString(),
                    isVerified: true
                };
                
                reviews.push(newReview);
                localStorage.setItem('klonglens_reviews', JSON.stringify(reviews));
                
                resolve(newReview);
            }, 1000);
        });
    }
    
    loadProductReviews(productId) {
        // โหลดรีวิวจาก localStorage
        const reviews = JSON.parse(localStorage.getItem('klonglens_reviews') || '[]');
        const productReviews = reviews.filter(review => 
            review.productId === productId && review.status === 'approved'
        );
        
        return productReviews.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }
    
    renderReviews(reviews, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        if (reviews.length === 0) {
            container.innerHTML = `
                <div class="no-reviews">
                    <i class="fas fa-comment-alt"></i>
                    <p>ยังไม่มีรีวิวสำหรับสินค้านี้</p>
                    <button class="write-review-btn" onclick="reviewsSystem.openReviewModal(window.currentProduct)">
                        เขียนรีวิวแรก
                    </button>
                </div>
            `;
            return;
        }
        
        const reviewsHTML = reviews.map(review => {
            const date = new Date(review.createdAt).toLocaleDateString('th-TH', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            
            return `
                <div class="review-item">
                    <div class="review-header">
                        <div class="reviewer-info">
                            <div class="reviewer-avatar">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="reviewer-details">
                                <h4 class="reviewer-name">${review.userName}</h4>
                                <div class="review-rating">
                                    ${this.renderStars(review.rating)}
                                </div>
                            </div>
                        </div>
                        <div class="review-date">${date}</div>
                    </div>
                    
                    ${review.title ? `<h5 class="review-title">${review.title}</h5>` : ''}
                    
                    <div class="review-content">
                        <p>${review.reviewText}</p>
                    </div>
                    
                    ${review.isVerified ? '<div class="verified-badge"><i class="fas fa-check-circle"></i> การซื้อที่ได้รับการยืนยัน</div>' : ''}
                </div>
            `;
        }).join('');
        
        container.innerHTML = reviewsHTML;
    }
    
    renderStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        
        let starsHTML = '';
        
        // Full stars
        for (let i = 0; i < fullStars; i++) {
            starsHTML += '<i class="fas fa-star"></i>';
        }
        
        // Half star
        if (hasHalfStar) {
            starsHTML += '<i class="fas fa-star-half-alt"></i>';
        }
        
        // Empty stars
        for (let i = 0; i < emptyStars; i++) {
            starsHTML += '<i class="far fa-star"></i>';
        }
        
        return starsHTML;
    }
    
    calculateAverageRating(reviews) {
        if (reviews.length === 0) return 0;
        
        const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
        return (totalRating / reviews.length).toFixed(1);
    }
    
    getRatingDistribution(reviews) {
        const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
        
        reviews.forEach(review => {
            const rating = Math.floor(review.rating);
            if (distribution[rating] !== undefined) {
                distribution[rating]++;
            }
        });
        
        return distribution;
    }
    
    checkLoginStatus() {
        // จำลองการตรวจสอบสถานะการเข้าสู่ระบบ
        return localStorage.getItem('klonglens_user_logged_in') === 'true';
    }
    
    showSuccess(message) {
        // สร้าง notification แสดงความสำเร็จ
        const notification = document.createElement('div');
        notification.className = 'notification success';
        notification.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        `;
        
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background-color: #4CAF50;
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            z-index: 10001;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideInRight 0.3s ease;
            max-width: 350px;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }
    
    showError(message) {
        // สร้าง notification แสดงข้อผิดพลาด
        const notification = document.createElement('div');
        notification.className = 'notification error';
        notification.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <span>${message}</span>
        `;
        
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background-color: #f44336;
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            z-index: 10001;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideInRight 0.3s ease;
            max-width: 350px;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }
}

// Initialize reviews system
const reviewsSystem = new ReviewsSystem();

// Export for global access
window.ReviewsSystem = ReviewsSystem;
window.reviewsSystem = reviewsSystem;
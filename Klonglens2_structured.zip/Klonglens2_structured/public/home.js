// Home page specific functionality
class HomePage {
    constructor() {
        this.init();
    }

    init() {
        this.loadProducts();
        this.initBrandsSlider();
        this.initProductInteractions();
    }

    // Sample product data
    getProductsData() {
        return [
            {
                id: 1,
                name: "Canon EOS R6 Mark II Mirrorless Camera",
                price: 2500,
                image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop",
                category: "mirrorless",
                brand: "Canon",
                featured: true
            },
            {
                id: 2,
                name: "Sony FX3 Full-Frame Cinema Camera",
                price: 3200,
                image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop",
                category: "cinema",
                brand: "Sony",
                featured: true
            },
            {
                id: 3,
                name: "Canon RF 24-70mm f/2.8L IS USM",
                price: 1800,
                image: "https://images.unsplash.com/photo-1606983340077-882fe2c049c8?w=400&h=300&fit=crop",
                category: "lens",
                brand: "Canon",
                featured: true
            },
            {
                id: 4,
                name: "DJI Ronin 4D Cinema Camera",
                price: 4500,
                image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop",
                category: "cinema",
                brand: "DJI",
                featured: true
            },
            {
                id: 5,
                name: "Blackmagic ATEM Mini Pro ISO",
                price: 1000,
                image: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=300&fit=crop",
                category: "switcher",
                brand: "Blackmagic",
                featured: true
            },
            {
                id: 6,
                name: "Sony A7S III Mirrorless Camera",
                price: 2800,
                image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop",
                category: "mirrorless",
                brand: "Sony",
                featured: true
            }
        ];
    }

    // Load and display products
    loadProducts() {
        const productsGrid = document.getElementById('products-grid');
        if (!productsGrid) return;

        const products = this.getProductsData();
        
        productsGrid.innerHTML = products.map(product => `
            <div class="product-card" data-product-id="${product.id}">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                </div>
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-price">${this.formatPrice(product.price)}/วัน</div>
                    <button class="add-to-cart" data-product-id="${product.id}">
                        <i class="fas fa-plus"></i> เพิ่มลงตะกร้า
                    </button>
                </div>
            </div>
        `).join('');
    }

    // Initialize brands slider
    initBrandsSlider() {
        const slider = document.querySelector('.brands-slider');
        const nextBtn = document.getElementById('brands-next');
        
        if (nextBtn && slider) {
            nextBtn.addEventListener('click', () => {
                const scrollAmount = 220; // Brand item width + gap
                slider.scrollBy({ left: scrollAmount, behavior: 'smooth' });
            });
        }

        // Auto-scroll brands
        if (slider) {
            setInterval(() => {
                const maxScroll = slider.scrollWidth - slider.clientWidth;
                if (slider.scrollLeft >= maxScroll) {
                    slider.scrollTo({ left: 0, behavior: 'smooth' });
                } else {
                    slider.scrollBy({ left: 220, behavior: 'smooth' });
                }
            }, 5000);
        }
    }

    // Initialize product interactions
    initProductInteractions() {
        // Add to cart functionality
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('add-to-cart') || e.target.closest('.add-to-cart')) {
                const button = e.target.classList.contains('add-to-cart') ? e.target : e.target.closest('.add-to-cart');
                const productId = parseInt(button.dataset.productId);
                const product = this.getProductsData().find(p => p.id === productId);
                
                if (product && window.KlonglensApp) {
                    window.KlonglensApp.addToCart(product);
                }
            }
        });

        // Product card click to view details
        document.addEventListener('click', (e) => {
            const productCard = e.target.closest('.product-card');
            if (productCard && !e.target.closest('.add-to-cart')) {
                const productId = productCard.dataset.productId;
                window.location.href = `product.html?id=${productId}`;
            }
        });

        // Category card clicks
        document.addEventListener('click', (e) => {
            const categoryCard = e.target.closest('.category-card');
            if (categoryCard) {
                // The href will handle navigation
                return;
            }
        });
    }

    // Utility function
    formatPrice(price) {
        return new Intl.NumberFormat('th-TH', {
            minimumFractionDigits: 0
        }).format(price);
    }
}

// Initialize home page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new HomePage();
});
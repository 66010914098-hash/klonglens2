// Authentication functionality
class AuthManager {
    constructor() {
        this.init();
    }

    init() {
        this.initPasswordToggles();
        this.initForms();
        this.initValidation();
    }

    // Password visibility toggle
    initPasswordToggles() {
        const toggleButtons = document.querySelectorAll('.toggle-password');
        
        toggleButtons.forEach(button => {
            button.addEventListener('click', () => {
                const passwordInput = button.parentElement.querySelector('input');
                const icon = button.querySelector('i');
                
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    passwordInput.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
    }

    // Form submissions
    initForms() {
        const loginForm = document.getElementById('login-form');
        const registerForm = document.getElementById('register-form');

        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin(loginForm);
            });
        }

        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRegister(registerForm);
            });
        }
    }

    // Real-time validation
    initValidation() {
        const inputs = document.querySelectorAll('input[required]');
        
        inputs.forEach(input => {
            input.addEventListener('blur', () => {
                this.validateField(input);
            });
            
            input.addEventListener('input', () => {
                this.clearValidation(input);
            });
        });

        // Special validation for password confirmation
        const confirmPassword = document.getElementById('confirm-password');
        const password = document.getElementById('password');
        
        if (confirmPassword && password) {
            confirmPassword.addEventListener('input', () => {
                this.validatePasswordMatch();
            });
            
            password.addEventListener('input', () => {
                if (confirmPassword.value) {
                    this.validatePasswordMatch();
                }
            });
        }
    }

    // Field validation
    validateField(input) {
        const formGroup = input.closest('.form-group');
        const value = input.value.trim();
        
        // Remove existing validation classes and messages
        this.clearValidation(input);
        
        // Required field validation
        if (input.hasAttribute('required') && !value) {
            this.showError(formGroup, 'กรุณากรอกข้อมูลนี้');
            return false;
        }
        
        // Email validation
        if (input.type === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                this.showError(formGroup, 'รูปแบบอีเมลไม่ถูกต้อง');
                return false;
            }
        }
        
        // Password validation
        if (input.type === 'password' && input.name === 'password' && value) {
            if (value.length < 6) {
                this.showError(formGroup, 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร');
                return false;
            }
        }
        
        // Phone validation
        if (input.type === 'tel' && value) {
            const phoneRegex = /^[0-9]{9,10}$/;
            if (!phoneRegex.test(value.replace(/[-\s]/g, ''))) {
                this.showError(formGroup, 'เบอร์โทรศัพท์ไม่ถูกต้อง');
                return false;
            }
        }
        
        // If validation passes
        this.showSuccess(formGroup);
        return true;
    }

    // Password match validation
    validatePasswordMatch() {
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm-password');
        const formGroup = confirmPassword.closest('.form-group');
        
        this.clearValidation(confirmPassword);
        
        if (confirmPassword.value && password.value !== confirmPassword.value) {
            this.showError(formGroup, 'รหัสผ่านไม่ตรงกัน');
            return false;
        } else if (confirmPassword.value) {
            this.showSuccess(formGroup);
            return true;
        }
        
        return true;
    }

    // Show validation error
    showError(formGroup, message) {
        formGroup.classList.add('error');
        formGroup.classList.remove('success');
        
        const existingError = formGroup.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
        formGroup.appendChild(errorElement);
    }

    // Show validation success
    showSuccess(formGroup) {
        formGroup.classList.add('success');
        formGroup.classList.remove('error');
        
        const existingError = formGroup.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
    }

    // Clear validation
    clearValidation(input) {
        const formGroup = input.closest('.form-group');
        formGroup.classList.remove('error', 'success');
        
        const existingError = formGroup.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
    }

    // Handle login
    async handleLogin(form) {
        const formData = new FormData(form);
        const email = formData.get('email');
        const password = formData.get('password');
        
        // Validate all fields
        const emailInput = form.querySelector('#email');
        const passwordInput = form.querySelector('#password');
        
        const emailValid = this.validateField(emailInput);
        const passwordValid = this.validateField(passwordInput);
        
        if (!emailValid || !passwordValid) {
            return;
        }
        
        const submitBtn = form.querySelector('.auth-btn');
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;
        
        try {
            // Simulate API call
            await this.delay(2000);
            
            // Mock authentication - in real app, this would be an API call
            if (email && password) {
                // Store user session
                localStorage.setItem('klonglens_user', JSON.stringify({
                    email: email,
                    name: 'ผู้ใช้งาน',
                    loginTime: new Date().toISOString()
                }));
                
                // Redirect to home page
                window.location.href = 'index.html';
            } else {
                throw new Error('ข้อมูลเข้าสู่ระบบไม่ถูกต้อง');
            }
        } catch (error) {
            const emailGroup = emailInput.closest('.form-group');
            this.showError(emailGroup, error.message);
        } finally {
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
        }
    }

    // Handle registration
    async handleRegister(form) {
        const formData = new FormData(form);
        
        // Validate all fields
        const inputs = form.querySelectorAll('input[required]');
        let allValid = true;
        
        inputs.forEach(input => {
            if (!this.validateField(input)) {
                allValid = false;
            }
        });
        
        // Check password match
        if (!this.validatePasswordMatch()) {
            allValid = false;
        }
        
        // Check terms acceptance
        const termsCheckbox = form.querySelector('#terms');
        if (!termsCheckbox.checked) {
            const checkboxGroup = termsCheckbox.closest('.checkbox-group');
            const existingError = checkboxGroup.querySelector('.error-message');
            if (existingError) existingError.remove();
            
            const errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            errorElement.innerHTML = '<i class="fas fa-exclamation-circle"></i> กรุณายอมรับเงื่อนไขการใช้บริการ';
            checkboxGroup.appendChild(errorElement);
            allValid = false;
        }
        
        if (!allValid) {
            return;
        }
        
        const submitBtn = form.querySelector('.auth-btn');
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;
        
        try {
            // Simulate API call
            await this.delay(3000);
            
            // Mock registration success
            const userData = {
                email: formData.get('email'),
                name: `${formData.get('firstname_th')} ${formData.get('lastname_th')}`,
                phone: formData.get('phone'),
                registrationTime: new Date().toISOString()
            };
            
            // Store user session
            localStorage.setItem('klonglens_user', JSON.stringify(userData));
            
            // Show success message
            alert('สมัครสมาชิกสำเร็จ! ยินดีต้อนรับเข้าสู่เว็บไซต์ Klonglens');
            
            // Redirect to home page
            window.location.href = 'index.html';
            
        } catch (error) {
            alert('เกิดข้อผิดพลาด กรุณาลองอีกครั้ง');
        } finally {
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
        }
    }

    // Utility function for delays
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize authentication when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AuthManager();
});
// Cart page functionality
class CartPage {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('klonglens_cart')) || [];
        this.promoCode = null;
        this.shippingFee = 0;
        this.discount = 0;
        this.init();
    }

    init() {
        this.renderCart();
        this.updateSummary();
        this.initInteractions();
    }

    // Render cart items
    renderCart() {
        const cartContainer = document.getElementById('cart-items');
        const cartItemCount = document.getElementById('cart-item-count');
        
        if (!cartContainer) return;
        
        // Update item count
        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        if (cartItemCount) {
            cartItemCount.textContent = `${totalItems} รายการ`;
        }
        
        // Render empty state or cart items
        if (this.cart.length === 0) {
            this.renderEmptyCart(cartContainer);
        } else {
            this.renderCartItems(cartContainer);
        }
    }

    // Render empty cart
    renderEmptyCart(container) {
        container.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h3>ตะกร้าของคุณว่างเปล่า</h3>
                <p>คุณยังไม่ได้เพิ่มสินค้าใดลงในตะกร้า เริ่มเลือกอุปกรณ์ที่คุณต้องการกันเถอะ</p>
                <a href="categories.html" class="auth-btn">
                    <i class="fas fa-camera"></i>
                    เริ่มช้อปปิ้ง
                </a>
            </div>
        `;

        // Hide sidebar if cart is empty
        const sidebar = document.querySelector('.cart-sidebar');
        if (sidebar) {
            sidebar.style.display = 'none';
        }
    }

    // Render cart items
    renderCartItems(container) {
        // Show sidebar
        const sidebar = document.querySelector('.cart-sidebar');
        if (sidebar) {
            sidebar.style.display = 'flex';
        }

        container.innerHTML = this.cart.map((item, index) => `
            <div class="cart-item" data-item-index="${index}">
                <div class="item-header">
                    <div class="item-image">
                        <img src="${item.images ? item.images[0] : item.image}" alt="${item.name}">
                    </div>
                    <div class="item-details">
                        <h3 class="item-name">${item.name}</h3>
                        <div class="item-brand">${item.brand || 'Klonglens'}</div>
                        <div class="item-dates">
                            <span><i class="fas fa-calendar"></i> รับ: ${this.formatDate(item.pickupDate)}</span>
                            <span><i class="fas fa-calendar"></i> คืน: ${this.formatDate(item.returnDate)}</span>
                        </div>
                        <div class="item-delivery">
                            <i class="fas fa-${item.delivery === 'pickup' ? 'store' : 'motorcycle'}"></i>
                            ${item.delivery === 'pickup' ? 'รับเองที่ร้าน' : 'ส่ง Messenger'}
                            เวลา ${item.pickupTime || '09:00'}
                        </div>
                        ${item.promotion ? `
                            <div class="item-promotion">
                                <i class="fas fa-tag"></i>
                                โปรโมชั่น ${item.promotion.days} วัน
                            </div>
                        ` : ''}
                    </div>
                </div>
                
                <div class="item-actions">
                    <div class="quantity-controls">
                        <button class="quantity-btn" data-action="decrease" data-index="${index}" ${item.quantity <= 1 ? 'disabled' : ''}>
                            <i class="fas fa-minus"></i>
                        </button>
                        <span class="quantity-display">${item.quantity}</span>
                        <button class="quantity-btn" data-action="increase" data-index="${index}" ${item.quantity >= 10 ? 'disabled' : ''}>
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                    
                    <div class="item-price">
                        <div class="price-per-day">${this.formatPrice(this.getItemDailyPrice(item))}/วัน</div>
                        <div class="price-total">${this.formatPrice(this.getItemTotalPrice(item))}</div>
                    </div>
                    
                    <button class="remove-item" data-index="${index}" title="ลบออกจากตะกร้า">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    // Initialize interactions
    initInteractions() {
        // Quantity controls
        document.addEventListener('click', (e) => {
            if (e.target.closest('.quantity-btn')) {
                const button = e.target.closest('.quantity-btn');
                const action = button.dataset.action;
                const index = parseInt(button.dataset.index);
                
                if (action === 'increase') {
                    this.updateQuantity(index, this.cart[index].quantity + 1);
                } else if (action === 'decrease') {
                    this.updateQuantity(index, this.cart[index].quantity - 1);
                }
            }
        });

        // Remove item
        document.addEventListener('click', (e) => {
            if (e.target.closest('.remove-item')) {
                const button = e.target.closest('.remove-item');
                const index = parseInt(button.dataset.index);
                this.removeItem(index);
            }
        });

        // Promo code
        const applyPromoBtn = document.getElementById('apply-promo');
        if (applyPromoBtn) {
            applyPromoBtn.addEventListener('click', () => {
                this.applyPromoCode();
            });
        }

        const promoInput = document.getElementById('promo-code');
        if (promoInput) {
            promoInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.applyPromoCode();
                }
            });
        }

        // Checkout
        const checkoutBtn = document.getElementById('checkout-btn');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', () => {
                this.proceedToCheckout();
            });
        }
    }

    // Update item quantity
    updateQuantity(index, newQuantity) {
        if (newQuantity < 1 || newQuantity > 10) return;
        
        this.cart[index].quantity = newQuantity;
        this.cart[index].totalPrice = this.getItemTotalPrice(this.cart[index]);
        
        this.saveCart();
        this.renderCart();
        this.updateSummary();
        
        // Update global cart count
        if (window.KlonglensApp) {
            window.KlonglensApp.updateCartCount();
        }
        
        // Add update animation
        const cartItem = document.querySelector(`[data-item-index="${index}"]`);
        if (cartItem) {
            cartItem.classList.add('updated');
            setTimeout(() => {
                cartItem.classList.remove('updated');
            }, 300);
        }
    }

    // Remove item from cart
    removeItem(index) {
        const item = this.cart[index];
        
        if (confirm(`คุณต้องการลบ "${item.name}" ออกจากตะกร้าหรือไม่?`)) {
            this.cart.splice(index, 1);
            this.saveCart();
            this.renderCart();
            this.updateSummary();
            
            // Update global cart count
            if (window.KlonglensApp) {
                window.KlonglensApp.updateCartCount();
            }
        }
    }

    // Apply promo code
    applyPromoCode() {
        const promoInput = document.getElementById('promo-code');
        const code = promoInput?.value.trim().toUpperCase();
        
        if (!code) return;
        
        // Mock promo codes
        const promoCodes = {
            'WELCOME10': { type: 'percentage', value: 10, description: 'ส่วนลด 10%' },
            'SAVE500': { type: 'fixed', value: 500, description: 'ส่วนลด 500 บาท' },
            'FIRSTTIME': { type: 'percentage', value: 15, description: 'ส่วนลด 15% สำหรับสมาชิกใหม่' }
        };
        
        const promo = promoCodes[code];
        
        if (promo) {
            this.promoCode = promo;
            this.updateSummary();
            
            // Show success message
            this.showPromoMessage(`ใช้โค้ดส่วนลดสำเร็จ! ${promo.description}`, 'success');
            
            // Clear input
            promoInput.value = '';
        } else {
            this.showPromoMessage('โค้ดส่วนลดไม่ถูกต้องหรือหมดอายุแล้ว', 'error');
        }
    }

    // Show promo message
    showPromoMessage(message, type) {
        const promoCode = document.querySelector('.promo-code');
        if (!promoCode) return;
        
        // Remove existing message
        const existingMessage = promoCode.querySelector('.promo-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Create message element
        const messageElement = document.createElement('div');
        messageElement.className = `promo-message ${type}`;
        messageElement.textContent = message;
        messageElement.style.cssText = `
            margin-top: 0.5rem;
            padding: 0.5rem;
            border-radius: 5px;
            font-size: 0.9rem;
            text-align: center;
            background-color: ${type === 'success' ? 'rgba(39, 174, 96, 0.2)' : 'rgba(231, 76, 60, 0.2)'};
            color: ${type === 'success' ? '#27ae60' : '#e74c3c'};
            border: 1px solid ${type === 'success' ? '#27ae60' : '#e74c3c'};
        `;
        
        promoCode.appendChild(messageElement);
        
        // Remove message after 3 seconds
        setTimeout(() => {
            messageElement.remove();
        }, 3000);
    }

    // Update order summary
    updateSummary() {
        const subtotal = this.getSubtotal();
        this.shippingFee = this.calculateShippingFee();
        this.discount = this.calculateDiscount(subtotal);
        const total = subtotal + this.shippingFee - this.discount;
        
        // Update display
        const subtotalElement = document.getElementById('subtotal');
        const shippingElement = document.getElementById('shipping-fee');
        const discountElement = document.getElementById('discount');
        const totalElement = document.getElementById('total');
        
        if (subtotalElement) subtotalElement.textContent = this.formatPrice(subtotal);
        if (shippingElement) shippingElement.textContent = this.formatPrice(this.shippingFee);
        if (discountElement) discountElement.textContent = `-${this.formatPrice(this.discount)}`;
        if (totalElement) totalElement.textContent = this.formatPrice(total);
        
        // Update checkout button state
        const checkoutBtn = document.getElementById('checkout-btn');
        if (checkoutBtn) {
            checkoutBtn.disabled = this.cart.length === 0;
        }
    }

    // Calculate subtotal
    getSubtotal() {
        return this.cart.reduce((total, item) => total + this.getItemTotalPrice(item), 0);
    }

    // Calculate shipping fee
    calculateShippingFee() {
        const hasMessengerDelivery = this.cart.some(item => item.delivery === 'messenger');
        return hasMessengerDelivery ? 100 : 0;
    }

    // Calculate discount
    calculateDiscount(subtotal) {
        if (!this.promoCode) return 0;
        
        if (this.promoCode.type === 'percentage') {
            return Math.floor(subtotal * (this.promoCode.value / 100));
        } else if (this.promoCode.type === 'fixed') {
            return Math.min(this.promoCode.value, subtotal);
        }
        
        return 0;
    }

    // Get item daily price
    getItemDailyPrice(item) {
        if (item.promotion) {
            return item.promotion.daily;
        }
        return item.price;
    }

    // Get item total price
    getItemTotalPrice(item) {
        const dailyPrice = this.getItemDailyPrice(item);
        return dailyPrice * item.quantity;
    }

    // Proceed to checkout
    proceedToCheckout() {
        if (this.cart.length === 0) return;
        
        // In a real app, this would redirect to checkout page
        const total = this.getSubtotal() + this.shippingFee - this.discount;
        
        alert(`ขอบคุณสำหรับการสั่งซื้อ!\n\nยอดรวม: ${this.formatPrice(total)}\nจำนวนสินค้า: ${this.cart.length} รายการ\n\nข้อมูลการจัดส่งจะถูกส่งทางอีเมลในภายหลัง`);
        
        // Clear cart after successful order
        // this.cart = [];
        // this.saveCart();
        // window.location.href = 'index.html';
    }

    // Save cart to localStorage
    saveCart() {
        localStorage.setItem('klonglens_cart', JSON.stringify(this.cart));
    }

    // Utility functions
    formatPrice(price) {
        return new Intl.NumberFormat('th-TH', {
            minimumFractionDigits: 0
        }).format(price) + ' บาท';
    }

    formatDate(dateString) {
        if (!dateString) return 'ไม่ระบุ';
        
        const date = new Date(dateString);
        return date.toLocaleDateString('th-TH', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
}

// Initialize cart page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CartPage();
});
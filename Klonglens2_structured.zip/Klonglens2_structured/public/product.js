// Product detail page functionality
class ProductPage {
    constructor() {
        this.productId = this.getProductIdFromURL();
        this.selectedPromotion = null;
        this.selectedDelivery = 'pickup';
        this.selectedTime = null;
        this.quantity = 1;
        this.product = null;
        this.init();
    }

    init() {
        this.loadProduct();
        this.initInteractions();
    }

    // Get product ID from URL parameters
    getProductIdFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        return parseInt(urlParams.get('id')) || 1;
    }

    // Sample product data (in real app, this would come from API)
    getProductData() {
        const products = {
            1: {
                id: 1,
                name: "Canon EOS R6 Mark II Mirrorless Camera",
                price: 2500,
                images: [
                    "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=600&h=600&fit=crop",
                    "https://images.unsplash.com/photo-1606983340077-882fe2c049c8?w=600&h=600&fit=crop",
                    "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=600&h=600&fit=crop"
                ],
                category: "mirrorless",
                brand: "Canon",
                description: "กล้อง Mirrorless คุณภาพสูงจาก Canon ที่มาพร้อมเทคโนโลยีการถ่ายภาพและวิดีโอที่ทันสมัย",
                specifications: {
                    "เซนเซอร์": "Full Frame CMOS",
                    "ความละเอียด": "24.2 ล้านพิกเซล",
                    "ISO": "100-102,400",
                    "การบันทึกวิดีโอ": "4K 60fps",
                    "น้ำหนัก": "650g"
                },
                promotions: [
                    { days: 3, total: 6500, daily: 2167 },
                    { days: 7, total: 14000, daily: 2000 },
                    { days: 14, total: 24500, daily: 1750 }
                ]
            },
            5: {
                id: 5,
                name: "Blackmagic ATEM Mini Pro ISO HDMI Live Stream Switcher",
                price: 1000,
                images: [
                    "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=600&h=600&fit=crop",
                    "https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=600&h=600&fit=crop",
                    "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=600&h=600&fit=crop"
                ],
                category: "switcher",
                brand: "Blackmagic",
                description: "Live Stream Switcher สำหรับการสตรีมสด และผลิตรายการโทรทัศน์คุณภาพสูง",
                specifications: {
                    "อินพุต": "4x HDMI",
                    "เอาต์พุต": "HDMI, USB-C",
                    "ความละเอียด": "1080p60",
                    "สตรีมมิ่ง": "USB, Ethernet",
                    "น้ำหนัก": "1.3kg"
                },
                promotions: [
                    { days: 3, total: 2700, daily: 900 },
                    { days: 7, total: 5600, daily: 800 },
                    { days: 14, total: 9800, daily: 700 }
                ]
            }
        };
        
        return products[this.productId] || products[1];
    }

    // Load product data and render page
    loadProduct() {
        this.product = this.getProductData();
        this.renderProduct();
        this.updateBreadcrumb();
    }

    // Update breadcrumb
    updateBreadcrumb() {
        const breadcrumb = document.getElementById('breadcrumb');
        if (breadcrumb) {
            const currentSpan = breadcrumb.querySelector('.current');
            if (currentSpan) {
                currentSpan.textContent = this.product.name;
            }
        }
    }

    // Render product detail
    renderProduct() {
        const container = document.getElementById('product-detail');
        if (!container) return;

        container.innerHTML = `
            <div class="product-layout">
                <div class="product-images">
                    <div class="main-image">
                        <img src="${this.product.images[0]}" alt="${this.product.name}" id="main-image">
                    </div>
                    <div class="thumbnail-images">
                        ${this.product.images.map((img, index) => `
                            <div class="thumbnail ${index === 0 ? 'active' : ''}" data-image="${img}">
                                <img src="${img}" alt="ภาพ ${index + 1}">
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <div class="product-info">
                    <h1 class="product-title">${this.product.name}</h1>
                    <div class="product-price">${this.formatPrice(this.product.price)} <span class="price-unit">/วัน</span></div>
                    
                    <div class="promotions-section">
                        <h3>โปรโมชั่นแนะนำ</h3>
                        <div class="promotion-cards">
                            ${this.product.promotions.map((promo, index) => `
                                <div class="promotion-card" data-promo-index="${index}">
                                    <div class="promotion-days">${promo.days} วัน</div>
                                    <div class="promotion-total">รวม ${this.formatPrice(promo.total)}</div>
                                    <div class="promotion-daily">${this.formatPrice(promo.daily)}/วัน</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="delivery-section">
                        <h3>วิธีรับอุปกรณ์</h3>
                        <div class="delivery-options">
                            <div class="delivery-option selected" data-delivery="pickup">
                                <i class="fas fa-store"></i>
                                รับเองที่ร้าน
                            </div>
                            <div class="delivery-option" data-delivery="messenger">
                                <i class="fas fa-motorcycle"></i>
                                ส่ง Messenger
                            </div>
                        </div>
                    </div>
                    
                    <div class="date-section">
                        <h3>วันที่รับ</h3>
                        <div class="date-inputs">
                            <div class="date-group">
                                <label>วันที่รับอุปกรณ์</label>
                                <input type="date" id="pickup-date" min="${this.getTodayDate()}">
                            </div>
                            <div class="date-group">
                                <label>วันที่คืนอุปกรณ์</label>
                                <input type="date" id="return-date" min="${this.getTomorrowDate()}">
                            </div>
                        </div>
                    </div>
                    
                    <div class="time-section">
                        <h3>เวลารับ</h3>
                        <div class="time-info">
                            <i class="fas fa-info-circle"></i>
                            จันทร์ - เสาร์ ร้านปิด 19:00 น.
                        </div>
                        <div class="time-options">
                            <div class="time-option" data-time="09:00">
                                <div class="time">09:00 - 10:00</div>
                                <div class="status">เวลาปกติ</div>
                            </div>
                            <div class="time-option" data-time="10:00">
                                <div class="time">10:00 - 11:00</div>
                                <div class="status">เวลาปกติ</div>
                            </div>
                            <div class="time-option" data-time="11:00">
                                <div class="time">11:00 - 12:00</div>
                                <div class="status">เวลาปกติ</div>
                            </div>
                            <div class="time-option" data-time="13:00">
                                <div class="time">13:00 - 14:00</div>
                                <div class="status">เวลาปกติ</div>
                            </div>
                            <div class="time-option" data-time="14:00">
                                <div class="time">14:00 - 15:00</div>
                                <div class="status">เวลาปกติ</div>
                            </div>
                            <div class="time-option" data-time="20:00">
                                <div class="time">20:00 - 21:00</div>
                                <div class="status">นอกเวลา</div>
                                <div class="extra-charge">+50 บาท</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="add-to-cart-section">
                        <div class="quantity-selector">
                            <span class="quantity-label">จำนวน:</span>
                            <div class="quantity-controls">
                                <button class="quantity-btn" id="quantity-minus">-</button>
                                <input type="number" class="quantity-input" id="quantity-input" value="1" min="1" max="10">
                                <button class="quantity-btn" id="quantity-plus">+</button>
                            </div>
                        </div>
                        
                        <div class="total-price" id="total-price">
                            รวม: ${this.formatPrice(this.product.price)}
                        </div>
                        
                        <button class="add-to-cart-btn" id="add-to-cart-btn">
                            <i class="fas fa-plus"></i> เพิ่มลงตะกร้า
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="product-description">
                <h3>รายละเอียดสินค้า</h3>
                <div class="description-content">
                    <p>${this.product.description}</p>
                    <h4>สเปคสินค้า</h4>
                    <ul class="specs-list">
                        ${Object.entries(this.product.specifications).map(([key, value]) => `
                            <li>
                                <span class="spec-label">${key}</span>
                                <span class="spec-value">${value}</span>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            </div>
        `;
    }

    // Initialize interactions
    initInteractions() {
        // Image gallery
        this.initImageGallery();
        
        // Promotion selection
        this.initPromotionSelection();
        
        // Delivery options
        this.initDeliveryOptions();
        
        // Time selection
        this.initTimeSelection();
        
        // Quantity controls
        this.initQuantityControls();
        
        // Add to cart
        this.initAddToCart();
        
        // Date inputs
        this.initDateInputs();
    }

    // Image gallery functionality
    initImageGallery() {
        document.addEventListener('click', (e) => {
            if (e.target.closest('.thumbnail')) {
                const thumbnail = e.target.closest('.thumbnail');
                const imageUrl = thumbnail.dataset.image;
                const mainImage = document.getElementById('main-image');
                
                if (mainImage) {
                    mainImage.src = imageUrl;
                }
                
                // Update active thumbnail
                document.querySelectorAll('.thumbnail').forEach(thumb => thumb.classList.remove('active'));
                thumbnail.classList.add('active');
            }
        });
    }

    // Promotion selection
    initPromotionSelection() {
        document.addEventListener('click', (e) => {
            if (e.target.closest('.promotion-card')) {
                const card = e.target.closest('.promotion-card');
                const promoIndex = parseInt(card.dataset.promoIndex);
                
                // Update selection
                document.querySelectorAll('.promotion-card').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                
                this.selectedPromotion = this.product.promotions[promoIndex];
                this.updateTotalPrice();
            }
        });
    }

    // Delivery options
    initDeliveryOptions() {
        document.addEventListener('click', (e) => {
            if (e.target.closest('.delivery-option')) {
                const option = e.target.closest('.delivery-option');
                const deliveryType = option.dataset.delivery;
                
                // Update selection
                document.querySelectorAll('.delivery-option').forEach(o => o.classList.remove('selected'));
                option.classList.add('selected');
                
                this.selectedDelivery = deliveryType;
            }
        });
    }

    // Time selection
    initTimeSelection() {
        document.addEventListener('click', (e) => {
            if (e.target.closest('.time-option') && !e.target.closest('.time-option').classList.contains('disabled')) {
                const option = e.target.closest('.time-option');
                const time = option.dataset.time;
                
                // Update selection
                document.querySelectorAll('.time-option').forEach(o => o.classList.remove('selected'));
                option.classList.add('selected');
                
                this.selectedTime = time;
            }
        });
    }

    // Quantity controls
    initQuantityControls() {
        const minusBtn = document.getElementById('quantity-minus');
        const plusBtn = document.getElementById('quantity-plus');
        const quantityInput = document.getElementById('quantity-input');
        
        if (minusBtn) {
            minusBtn.addEventListener('click', () => {
                if (this.quantity > 1) {
                    this.quantity--;
                    quantityInput.value = this.quantity;
                    this.updateTotalPrice();
                }
            });
        }
        
        if (plusBtn) {
            plusBtn.addEventListener('click', () => {
                if (this.quantity < 10) {
                    this.quantity++;
                    quantityInput.value = this.quantity;
                    this.updateTotalPrice();
                }
            });
        }
        
        if (quantityInput) {
            quantityInput.addEventListener('change', () => {
                const newQuantity = parseInt(quantityInput.value);
                if (newQuantity >= 1 && newQuantity <= 10) {
                    this.quantity = newQuantity;
                    this.updateTotalPrice();
                } else {
                    quantityInput.value = this.quantity;
                }
            });
        }
    }

    // Add to cart functionality
    initAddToCart() {
        const addToCartBtn = document.getElementById('add-to-cart-btn');
        
        if (addToCartBtn) {
            addToCartBtn.addEventListener('click', () => {
                this.addToCart();
            });
        }
    }

    // Date inputs
    initDateInputs() {
        const pickupDate = document.getElementById('pickup-date');
        const returnDate = document.getElementById('return-date');
        
        if (pickupDate) {
            pickupDate.addEventListener('change', () => {
                if (returnDate && pickupDate.value) {
                    const nextDay = new Date(pickupDate.value);
                    nextDay.setDate(nextDay.getDate() + 1);
                    returnDate.min = nextDay.toISOString().split('T')[0];
                }
            });
        }
    }

    // Update total price display
    updateTotalPrice() {
        const totalPriceElement = document.getElementById('total-price');
        if (!totalPriceElement) return;
        
        let basePrice = this.product.price;
        
        if (this.selectedPromotion) {
            basePrice = this.selectedPromotion.daily;
        }
        
        const total = basePrice * this.quantity;
        totalPriceElement.textContent = `รวม: ${this.formatPrice(total)}`;
    }

    // Add product to cart
    addToCart() {
        const pickupDate = document.getElementById('pickup-date')?.value;
        const returnDate = document.getElementById('return-date')?.value;
        
        if (!pickupDate || !returnDate) {
            alert('กรุณาเลือกวันที่รับและคืนอุปกรณ์');
            return;
        }
        
        if (!this.selectedTime) {
            alert('กรุณาเลือกเวลารับอุปกรณ์');
            return;
        }
        
        const cartItem = {
            ...this.product,
            quantity: this.quantity,
            promotion: this.selectedPromotion,
            delivery: this.selectedDelivery,
            pickupDate: pickupDate,
            returnDate: returnDate,
            pickupTime: this.selectedTime,
            totalPrice: this.selectedPromotion ? 
                this.selectedPromotion.daily * this.quantity : 
                this.product.price * this.quantity
        };
        
        if (window.KlonglensApp) {
            window.KlonglensApp.addToCart(cartItem);
        }
    }

    // Utility functions
    getTodayDate() {
        const today = new Date();
        return today.toISOString().split('T')[0];
    }

    getTomorrowDate() {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        return tomorrow.toISOString().split('T')[0];
    }

    formatPrice(price) {
        return new Intl.NumberFormat('th-TH', {
            minimumFractionDigits: 0
        }).format(price) + ' บาท';
    }
}

// Initialize product page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ProductPage();
});
// ข้อมูลอุปกรณ์ Klonglens
const PRODUCTS_DATA = {
    cameras: {
        canon: [
            {
                id: 'canon_eos_r50',
                name: 'Canon EOS R50',
                brand: 'Canon',
                category: 'camera',
                type: 'mirrorless',
                price: 1500,
                dailyRate: 500,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'APS-C CMOS',
                    resolution: '24.2 MP',
                    videoRecording: '4K UHD',
                    mount: 'RF-S',
                    weight: '429g'
                },
                features: ['4K Video', 'Wi-Fi', 'Bluetooth', 'Touchscreen'],
                availability: true,
                stock: 5,
                rating: 4.5,
                reviewCount: 128
            },
            {
                id: 'canon_eos_rp',
                name: 'Canon EOS RP',
                brand: 'Canon',
                category: 'camera',
                type: 'mirrorless',
                price: 2000,
                dailyRate: 650,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '26.2 MP',
                    videoRecording: '4K UHD',
                    mount: 'RF',
                    weight: '485g'
                },
                features: ['4K Video', 'Wi-Fi', 'Bluetooth', 'Dual Pixel AF'],
                availability: true,
                stock: 3,
                rating: 4.3,
                reviewCount: 95
            },
            {
                id: 'canon_eos_r',
                name: 'Canon EOS R',
                brand: 'Canon',
                category: 'camera',
                type: 'mirrorless',
                price: 2500,
                dailyRate: 800,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '30.3 MP',
                    videoRecording: '4K UHD',
                    mount: 'RF',
                    weight: '660g'
                },
                features: ['4K Video', 'Wi-Fi', 'Bluetooth', 'IBIS', 'Weather Sealed'],
                availability: true,
                stock: 2,
                rating: 4.6,
                reviewCount: 203
            },
            {
                id: 'canon_eos_r6',
                name: 'Canon EOS R6',
                brand: 'Canon',
                category: 'camera',
                type: 'mirrorless',
                price: 3500,
                dailyRate: 1200,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '20.1 MP',
                    videoRecording: '4K UHD 60p',
                    mount: 'RF',
                    weight: '680g'
                },
                features: ['4K Video 60p', 'Wi-Fi', 'Bluetooth', 'IBIS', 'Weather Sealed', 'Dual Card Slots'],
                availability: true,
                stock: 4,
                rating: 4.8,
                reviewCount: 167
            },
            {
                id: 'canon_eos_r6ii',
                name: 'Canon EOS R6 Mark II',
                brand: 'Canon',
                category: 'camera',
                type: 'mirrorless',
                price: 4000,
                dailyRate: 1400,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '24.2 MP',
                    videoRecording: '4K UHD 60p',
                    mount: 'RF',
                    weight: '670g'
                },
                features: ['4K Video 60p', 'Wi-Fi', 'Bluetooth', 'IBIS', 'Weather Sealed', 'Focus Stacking'],
                availability: true,
                stock: 2,
                rating: 4.9,
                reviewCount: 89
            },
            {
                id: 'canon_eos_r5',
                name: 'Canon EOS R5',
                brand: 'Canon',
                category: 'camera',
                type: 'mirrorless',
                price: 5500,
                dailyRate: 1800,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '45 MP',
                    videoRecording: '8K RAW',
                    mount: 'RF',
                    weight: '738g'
                },
                features: ['8K Video', 'Wi-Fi', 'Bluetooth', 'IBIS', 'Weather Sealed', 'Dual Card Slots', '12fps Burst'],
                availability: true,
                stock: 1,
                rating: 4.9,
                reviewCount: 245
            }
        ],
        nikon: [
            {
                id: 'nikon_z50ii',
                name: 'Nikon Z50 II',
                brand: 'Nikon',
                category: 'camera',
                type: 'mirrorless',
                price: 1600,
                dailyRate: 550,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'APS-C CMOS',
                    resolution: '20.9 MP',
                    videoRecording: '4K UHD',
                    mount: 'Z-mount',
                    weight: '450g'
                },
                features: ['4K Video', 'Wi-Fi', 'Bluetooth', 'Touchscreen', 'SnapBridge'],
                availability: true,
                stock: 3,
                rating: 4.4,
                reviewCount: 76
            },
            {
                id: 'nikon_z5',
                name: 'Nikon Z5',
                brand: 'Nikon',
                category: 'camera',
                type: 'mirrorless',
                price: 2200,
                dailyRate: 750,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '24.3 MP',
                    videoRecording: '4K UHD',
                    mount: 'Z-mount',
                    weight: '675g'
                },
                features: ['4K Video', 'Wi-Fi', 'Bluetooth', 'IBIS', 'Weather Sealed', 'Dual Card Slots'],
                availability: true,
                stock: 2,
                rating: 4.5,
                reviewCount: 134
            },
            {
                id: 'nikon_z6ii',
                name: 'Nikon Z6 II',
                brand: 'Nikon',
                category: 'camera',
                type: 'mirrorless',
                price: 3000,
                dailyRate: 1000,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '24.5 MP',
                    videoRecording: '4K UHD 60p',
                    mount: 'Z-mount',
                    weight: '705g'
                },
                features: ['4K Video 60p', 'Wi-Fi', 'Bluetooth', 'IBIS', 'Weather Sealed', 'Dual Processors'],
                availability: true,
                stock: 2,
                rating: 4.7,
                reviewCount: 156
            }
        ],
        sony: [
            {
                id: 'sony_a7cii',
                name: 'Sony A7C II',
                brand: 'Sony',
                category: 'camera',
                type: 'mirrorless',
                price: 3200,
                dailyRate: 1100,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '33 MP',
                    videoRecording: '4K UHD 60p',
                    mount: 'E-mount',
                    weight: '515g'
                },
                features: ['4K Video 60p', 'Wi-Fi', 'Bluetooth', 'IBIS', 'Real-time Eye AF', 'Compact Design'],
                availability: true,
                stock: 3,
                rating: 4.6,
                reviewCount: 98
            },
            {
                id: 'sony_a7iv',
                name: 'Sony A7 IV',
                brand: 'Sony',
                category: 'camera',
                type: 'mirrorless',
                price: 4500,
                dailyRate: 1500,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop',
                specs: {
                    sensor: 'Full Frame CMOS',
                    resolution: '33 MP',
                    videoRecording: '4K UHD 60p',
                    mount: 'E-mount',
                    weight: '658g'
                },
                features: ['4K Video 60p', 'Wi-Fi', 'Bluetooth', 'IBIS', 'Real-time Eye AF', 'Dual Card Slots', '10fps Burst'],
                availability: true,
                stock: 2,
                rating: 4.8,
                reviewCount: 234
            }
        ]
    },
    lenses: {
        canon: [
            {
                id: 'canon_rf_24_70_f28',
                name: 'Canon RF 24-70mm f/2.8L IS USM',
                brand: 'Canon',
                category: 'lens',
                type: 'zoom',
                mount: 'RF',
                price: 2000,
                dailyRate: 600,
                image: 'https://images.unsplash.com/photo-1606983340077-882fe2c049c8?w=400&h=300&fit=crop',
                specs: {
                    focalLength: '24-70mm',
                    aperture: 'f/2.8',
                    mount: 'Canon RF',
                    weight: '900g',
                    filterSize: '82mm'
                },
                features: ['Image Stabilization', 'Weather Sealed', 'USM Motor', 'Nano USM'],
                availability: true,
                stock: 4,
                rating: 4.7,
                reviewCount: 145
            },
            {
                id: 'canon_rf_50_f12',
                name: 'Canon RF 50mm f/1.2L USM',
                brand: 'Canon',
                category: 'lens',
                type: 'prime',
                mount: 'RF',
                price: 1800,
                dailyRate: 550,
                image: 'https://images.unsplash.com/photo-1606983340077-882fe2c049c8?w=400&h=300&fit=crop',
                specs: {
                    focalLength: '50mm',
                    aperture: 'f/1.2',
                    mount: 'Canon RF',
                    weight: '950g',
                    filterSize: '77mm'
                },
                features: ['Ultra-wide f/1.2', 'USM Motor', 'Weather Sealed', 'Bokeh Control'],
                availability: true,
                stock: 2,
                rating: 4.9,
                reviewCount: 89
            }
        ],
        nikon: [
            {
                id: 'nikon_z_24_70_f28',
                name: 'Nikkor Z 24-70mm f/2.8 S',
                brand: 'Nikon',
                category: 'lens',
                type: 'zoom',
                mount: 'Z-mount',
                price: 1900,
                dailyRate: 580,
                image: 'https://images.unsplash.com/photo-1606983340077-882fe2c049c8?w=400&h=300&fit=crop',
                specs: {
                    focalLength: '24-70mm',
                    aperture: 'f/2.8',
                    mount: 'Nikon Z',
                    weight: '805g',
                    filterSize: '82mm'
                },
                features: ['Nano Crystal Coat', 'Weather Sealed', 'Stepping Motor', 'S-Line Quality'],
                availability: true,
                stock: 3,
                rating: 4.6,
                reviewCount: 112
            }
        ],
        sony: [
            {
                id: 'sony_fe_24_70_f28_gm',
                name: 'Sony FE 24-70mm f/2.8 GM',
                brand: 'Sony',
                category: 'lens',
                type: 'zoom',
                mount: 'E-mount',
                price: 2100,
                dailyRate: 650,
                image: 'https://images.unsplash.com/photo-1606983340077-882fe2c049c8?w=400&h=300&fit=crop',
                specs: {
                    focalLength: '24-70mm',
                    aperture: 'f/2.8',
                    mount: 'Sony E',
                    weight: '886g',
                    filterSize: '82mm'
                },
                features: ['G Master Quality', 'XA Elements', 'Direct Drive SSM', 'Dust/Moisture Resistant'],
                availability: true,
                stock: 2,
                rating: 4.8,
                reviewCount: 178
            }
        ]
    },
    accessories: [
        {
            id: 'tripod_manfrotto_mt190',
            name: 'ขาตั้งกล้อง Manfrotto MT190XPRO4',
            brand: 'Manfrotto',
            category: 'accessory',
            type: 'tripod',
            price: 400,
            dailyRate: 150,
            image: 'https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=400&h=300&fit=crop',
            specs: {
                material: 'Carbon Fiber',
                maxHeight: '170cm',
                minHeight: '9cm',
                weight: '1.5kg',
                maxLoad: '7kg'
            },
            features: ['Carbon Fiber', '90° Center Column', 'Quick Power Locks', 'Professional Grade'],
            availability: true,
            stock: 8,
            rating: 4.7,
            reviewCount: 156
        },
        {
            id: 'mic_rode_wireless_go2',
            name: 'ไมค์ไร้สาย RODE Wireless GO II',
            brand: 'RODE',
            category: 'accessory',
            type: 'microphone',
            price: 600,
            dailyRate: 200,
            image: 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=400&h=300&fit=crop',
            specs: {
                type: 'Wireless Lavalier',
                range: '200m',
                batteryLife: '7 hours',
                channels: '2.4GHz Digital',
                weight: '31g'
            },
            features: ['Dual Channel', 'On-board Recording', 'Universal Compatibility', 'Smart Gain'],
            availability: true,
            stock: 6,
            rating: 4.8,
            reviewCount: 203
        },
        {
            id: 'light_godox_sl60w',
            name: 'ไฟสตูดิโอ Godox SL-60W LED',
            brand: 'Godox',
            category: 'accessory',
            type: 'lighting',
            price: 800,
            dailyRate: 250,
            image: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=400&h=300&fit=crop',
            specs: {
                power: '60W LED',
                colorTemp: '5600K',
                cri: '96+',
                control: 'App Control',
                weight: '1.85kg'
            },
            features: ['Daylight Balanced', 'App Control', 'Fanless Design', 'Bowens Mount'],
            availability: true,
            stock: 4,
            rating: 4.6,
            reviewCount: 87
        }
    ]
};

// ฟังก์ชันสำหรับค้นหาและกรองข้อมูล
class ProductService {
    static getAllProducts() {
        const allProducts = [];
        
        // รวมกล้องทุกยี่ห้อ
        Object.values(PRODUCTS_DATA.cameras).forEach(brandProducts => {
            allProducts.push(...brandProducts);
        });
        
        // รวมเลนส์ทุกยี่ห้อ
        Object.values(PRODUCTS_DATA.lenses).forEach(brandProducts => {
            allProducts.push(...brandProducts);
        });
        
        // รวมอุปกรณ์เสริม
        allProducts.push(...PRODUCTS_DATA.accessories);
        
        return allProducts;
    }
    
    static getProductById(id) {
        return this.getAllProducts().find(product => product.id === id);
    }
    
    static searchProducts(query, filters = {}) {
        let products = this.getAllProducts();
        
        // ค้นหาตามคีย์เวิร์ด
        if (query) {
            const searchTerm = query.toLowerCase();
            products = products.filter(product => 
                product.name.toLowerCase().includes(searchTerm) ||
                product.brand.toLowerCase().includes(searchTerm) ||
                product.category.toLowerCase().includes(searchTerm)
            );
        }
        
        // กรองตามหมวดหมู่
        if (filters.category) {
            products = products.filter(product => product.category === filters.category);
        }
        
        // กรองตามยี่ห้อ
        if (filters.brand) {
            products = products.filter(product => product.brand.toLowerCase() === filters.brand.toLowerCase());
        }
        
        // กรองตามราคา
        if (filters.minPrice) {
            products = products.filter(product => product.dailyRate >= filters.minPrice);
        }
        
        if (filters.maxPrice) {
            products = products.filter(product => product.dailyRate <= filters.maxPrice);
        }
        
        // กรองเฉพาะสินค้าที่มีสต็อก
        if (filters.inStock) {
            products = products.filter(product => product.availability && product.stock > 0);
        }
        
        // เรียงลำดับ
        if (filters.sortBy) {
            switch (filters.sortBy) {
                case 'price_asc':
                    products.sort((a, b) => a.dailyRate - b.dailyRate);
                    break;
                case 'price_desc':
                    products.sort((a, b) => b.dailyRate - a.dailyRate);
                    break;
                case 'rating':
                    products.sort((a, b) => b.rating - a.rating);
                    break;
                case 'name':
                    products.sort((a, b) => a.name.localeCompare(b.name, 'th'));
                    break;
                default:
                    break;
            }
        }
        
        return products;
    }
    
    static getProductsByCategory(category) {
        return this.searchProducts('', { category });
    }
    
    static getProductsByBrand(brand) {
        return this.searchProducts('', { brand });
    }
}

// ส่งออกข้อมูลและคลาสสำหรับใช้งาน
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { PRODUCTS_DATA, ProductService };
} else {
    window.PRODUCTS_DATA = PRODUCTS_DATA;
    window.ProductService = ProductService;
}
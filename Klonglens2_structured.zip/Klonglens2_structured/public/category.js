// Category page functionality
class CategoryPage {
    constructor() {
        this.categoryType = this.getCategoryFromURL();
        this.allProducts = [];
        this.filteredProducts = [];
        this.displayedProducts = [];
        this.currentPage = 1;
        this.productsPerPage = 12;
        this.filters = {
            search: '',
            sort: 'name',
            brand: '',
            price: ''
        };
        this.init();
    }

    init() {
        this.loadCategoryData();
        this.loadProducts();
        this.initFilters();
        this.initLoadMore();
    }

    // Get category from URL
    getCategoryFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('type') || 'camera';
    }

    // Load category data
    loadCategoryData() {
        const categories = {
            camera: { name: 'กล้อง', description: 'กล้องดิจิทัลและกล้องฟิล์ม' },
            lens: { name: 'เลนส์', description: 'เลนส์หลากหลายรูปแบบ' },
            mirrorless: { name: 'Mirrorless', description: 'กล้องไม่มีกระจกสะท้อน' },
            dslr: { name: 'DSLR', description: 'กล้องรีเฟลกซ์ดิจิทัล' },
            gopro: { name: 'GoPro', description: 'กล้องแอคชั่น กันน้ำ กันสั่น' },
            actioncam: { name: 'ActionCam', description: 'กล้องสำหรับกิจกรรมกีฬา' },
            compact: { name: 'Compact', description: 'กล้องคอมแปคต์พกพา' },
            accessories: { name: 'อุปกรณ์เสริม', description: 'ขาตั้ง สายสะพาย เลนส์ฟิลเตอร์' },
            lighting: { name: 'อุปกรณ์แสง', description: 'ไฟสตูดิโอ แสงสตรอบ' }
        };

        const category = categories[this.categoryType] || categories.camera;
        
        // Update page elements
        document.getElementById('page-title').textContent = `${category.name} - Klonglens`;
        document.getElementById('category-name').textContent = category.name;
        document.getElementById('category-title').textContent = category.name;
        document.getElementById('category-description').textContent = category.description;
    }

    // Load products data
    loadProducts() {
        // Show loading
        this.showLoading();
        
        // Simulate API call
        setTimeout(() => {
            this.allProducts = this.generateProductsData();
            this.filteredProducts = [...this.allProducts];
            this.updateProductCount();
            this.populateBrandFilter();
            this.displayProducts();
        }, 1000);
    }

    // Generate sample products data
    generateProductsData() {
        const baseProducts = {
            camera: [
                { name: "Canon EOS R6 Mark II", brand: "Canon", price: 2500 },
                { name: "Sony A7S III", brand: "Sony", price: 2800 },
                { name: "Nikon Z9", brand: "Nikon", price: 3200 },
                { name: "Fujifilm X-T5", brand: "Fujifilm", price: 2200 },
                { name: "Canon EOS R5", brand: "Canon", price: 3000 },
                { name: "Sony A7R V", brand: "Sony", price: 3500 }
            ],
            lens: [
                { name: "Canon RF 24-70mm f/2.8L", brand: "Canon", price: 1800 },
                { name: "Sony FE 70-200mm f/2.8 GM", brand: "Sony", price: 2000 },
                { name: "Nikon Z 85mm f/1.8 S", brand: "Nikon", price: 1200 },
                { name: "Sigma 35mm f/1.4 DG DN Art", brand: "Sigma", price: 1000 },
                { name: "Tamron 28-75mm f/2.8 Di III", brand: "Tamron", price: 800 }
            ],
            mirrorless: [
                { name: "Sony A7 IV", brand: "Sony", price: 2400 },
                { name: "Canon EOS R6", brand: "Canon", price: 2200 },
                { name: "Fujifilm X-H2S", brand: "Fujifilm", price: 2600 },
                { name: "Olympus OM-1", brand: "Olympus", price: 2000 }
            ],
            gopro: [
                { name: "GoPro Hero 12 Black", brand: "GoPro", price: 500 },
                { name: "GoPro Hero 11 Black", brand: "GoPro", price: 450 },
                { name: "DJI Action 4", brand: "DJI", price: 400 }
            ]
        };

        const categoryProducts = baseProducts[this.categoryType] || baseProducts.camera;
        
        return categoryProducts.map((product, index) => ({
            id: Date.now() + index,
            name: product.name,
            brand: product.brand,
            price: product.price,
            image: `https://images.unsplash.com/photo-${1502920917128 + index}?w=400&h=300&fit=crop`,
            category: this.categoryType,
            featured: index < 3
        }));
    }

    // Show loading skeleton
    showLoading() {
        const grid = document.getElementById('products-grid');
        grid.innerHTML = '';
        
        for (let i = 0; i < 6; i++) {
            const skeleton = document.createElement('div');
            skeleton.className = 'skeleton-product';
            skeleton.innerHTML = `
                <div class="skeleton-image"></div>
                <div class="skeleton-content">
                    <div class="skeleton-text title"></div>
                    <div class="skeleton-text"></div>
                    <div class="skeleton-text price"></div>
                    <div class="skeleton-text button"></div>
                </div>
            `;
            grid.appendChild(skeleton);
        }
    }

    // Update product count
    updateProductCount() {
        const countElement = document.getElementById('category-count');
        if (countElement) {
            countElement.textContent = `${this.filteredProducts.length} รายการ`;
        }
    }

    // Populate brand filter
    populateBrandFilter() {
        const brandFilter = document.getElementById('brand-filter');
        if (!brandFilter) return;
        
        const brands = [...new Set(this.allProducts.map(p => p.brand))].sort();
        
        // Clear existing options except "ทั้งหมด"
        brandFilter.innerHTML = '<option value="">ทั้งหมด</option>';
        
        brands.forEach(brand => {
            const option = document.createElement('option');
            option.value = brand;
            option.textContent = brand;
            brandFilter.appendChild(option);
        });
    }

    // Initialize filters
    initFilters() {
        // Search
        const searchInput = document.getElementById('category-search');
        const searchBtn = document.getElementById('search-btn');
        
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filters.search = e.target.value;
                this.debounce(() => this.applyFilters(), 300);
            });
        }
        
        if (searchBtn) {
            searchBtn.addEventListener('click', () => {
                this.applyFilters();
            });
        }
        
        // Sort filter
        const sortFilter = document.getElementById('sort-filter');
        if (sortFilter) {
            sortFilter.addEventListener('change', (e) => {
                this.filters.sort = e.target.value;
                this.applyFilters();
            });
        }
        
        // Brand filter
        const brandFilter = document.getElementById('brand-filter');
        if (brandFilter) {
            brandFilter.addEventListener('change', (e) => {
                this.filters.brand = e.target.value;
                this.applyFilters();
            });
        }
        
        // Price filter
        const priceFilter = document.getElementById('price-filter');
        if (priceFilter) {
            priceFilter.addEventListener('change', (e) => {
                this.filters.price = e.target.value;
                this.applyFilters();
            });
        }
    }

    // Apply filters
    applyFilters() {
        let filtered = [...this.allProducts];
        
        // Search filter
        if (this.filters.search) {
            const searchTerm = this.filters.search.toLowerCase();
            filtered = filtered.filter(product => 
                product.name.toLowerCase().includes(searchTerm) ||
                product.brand.toLowerCase().includes(searchTerm)
            );
        }
        
        // Brand filter
        if (this.filters.brand) {
            filtered = filtered.filter(product => product.brand === this.filters.brand);
        }
        
        // Price filter
        if (this.filters.price) {
            filtered = filtered.filter(product => {
                const price = product.price;
                switch (this.filters.price) {
                    case '0-1000': return price <= 1000;
                    case '1000-2500': return price > 1000 && price <= 2500;
                    case '2500-5000': return price > 2500 && price <= 5000;
                    case '5000+': return price > 5000;
                    default: return true;
                }
            });
        }
        
        // Sort
        filtered.sort((a, b) => {
            switch (this.filters.sort) {
                case 'price-low': return a.price - b.price;
                case 'price-high': return b.price - a.price;
                case 'brand': return a.brand.localeCompare(b.brand);
                case 'name':
                default: return a.name.localeCompare(b.name);
            }
        });
        
        this.filteredProducts = filtered;
        this.currentPage = 1;
        this.updateProductCount();
        this.displayProducts();
    }

    // Display products
    displayProducts() {
        const grid = document.getElementById('products-grid');
        if (!grid) return;
        
        const startIndex = 0;
        const endIndex = this.currentPage * this.productsPerPage;
        this.displayedProducts = this.filteredProducts.slice(startIndex, endIndex);
        
        if (this.displayedProducts.length === 0) {
            this.showNoResults(grid);
        } else {
            this.renderProducts(grid);
        }
        
        this.updateLoadMoreButton();
    }

    // Render products
    renderProducts(container) {
        container.innerHTML = this.displayedProducts.map(product => `
            <div class="product-card" data-product-id="${product.id}">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                </div>
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-brand">${product.brand}</div>
                    <div class="product-price">${this.formatPrice(product.price)}/วัน</div>
                    <button class="add-to-cart" data-product-id="${product.id}">
                        <i class="fas fa-plus"></i> เพิ่มลงตะกร้า
                    </button>
                </div>
            </div>
        `).join('');
        
        // Add interactions
        this.initProductInteractions();
    }

    // Show no results
    showNoResults(container) {
        container.innerHTML = `
            <div class="no-results">
                <i class="fas fa-search"></i>
                <h3>ไม่พบสินค้าที่ตรงกับเงื่อนไข</h3>
                <p>ลองปรับเปลี่ยนคำค้นหาหรือตัวกรองเพื่อหาสินค้าที่คุณต้องการ</p>
                <button class="clear-filters-btn" onclick="location.reload()">ล้างตัวกรอง</button>
            </div>
        `;
    }

    // Initialize product interactions
    initProductInteractions() {
        // Product click to view details
        document.querySelectorAll('.product-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.add-to-cart')) {
                    const productId = card.dataset.productId;
                    window.location.href = `product.html?id=${productId}`;
                }
            });
        });
        
        // Add to cart
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                const productId = parseInt(button.dataset.productId);
                const product = this.displayedProducts.find(p => p.id === productId);
                
                if (product && window.KlonglensApp) {
                    window.KlonglensApp.addToCart(product);
                }
            });
        });
    }

    // Initialize load more
    initLoadMore() {
        const loadMoreBtn = document.getElementById('load-more-btn');
        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', () => {
                this.loadMoreProducts();
            });
        }
    }

    // Load more products
    loadMoreProducts() {
        const loadMoreBtn = document.getElementById('load-more-btn');
        const spinner = loadMoreBtn.querySelector('.fa-spinner');
        
        // Show loading
        spinner.style.display = 'inline-block';
        loadMoreBtn.disabled = true;
        
        setTimeout(() => {
            this.currentPage++;
            this.displayProducts();
            
            // Hide loading
            spinner.style.display = 'none';
            loadMoreBtn.disabled = false;
        }, 1000);
    }

    // Update load more button
    updateLoadMoreButton() {
        const loadMoreContainer = document.getElementById('load-more-container');
        const hasMore = this.displayedProducts.length < this.filteredProducts.length;
        
        if (loadMoreContainer) {
            loadMoreContainer.style.display = hasMore ? 'block' : 'none';
        }
    }

    // Utility functions
    formatPrice(price) {
        return new Intl.NumberFormat('th-TH', {
            minimumFractionDigits: 0
        }).format(price);
    }

    // Debounce function
    debounce(func, wait) {
        if (this.debounceTimeout) {
            clearTimeout(this.debounceTimeout);
        }
        this.debounceTimeout = setTimeout(func, wait);
    }
}

// Initialize category page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CategoryPage();
});
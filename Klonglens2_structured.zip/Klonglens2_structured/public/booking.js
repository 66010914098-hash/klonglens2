// Booking System for Klonglens
class BookingSystem {
    constructor() {
        this.currentBooking = null;
        this.minRentalDays = 1;
        this.maxRentalDays = 30;
        this.deliveryFee = 100;
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.setMinDate();
    }
    
    bindEvents() {
        // Booking modal controls
        const bookingModal = document.getElementById('booking-modal');
        const closeBooking = document.getElementById('close-booking');
        const cancelBooking = document.getElementById('cancel-booking');
        const bookingForm = document.getElementById('booking-form');
        
        if (closeBooking) {
            closeBooking.addEventListener('click', () => this.closeBookingModal());
        }
        
        if (cancelBooking) {
            cancelBooking.addEventListener('click', () => this.closeBookingModal());
        }
        
        if (bookingForm) {
            bookingForm.addEventListener('submit', (e) => this.handleBookingSubmit(e));
        }
        
        // Date inputs
        const startDate = document.getElementById('rental-start');
        const endDate = document.getElementById('rental-end');
        
        if (startDate) {
            startDate.addEventListener('change', () => this.calculateRental());
        }
        
        if (endDate) {
            endDate.addEventListener('change', () => this.calculateRental());
        }
        
        // Quantity selector
        const quantity = document.getElementById('quantity');
        if (quantity) {
            quantity.addEventListener('change', () => this.calculateRental());
        }
        
        // Delivery method
        document.querySelectorAll('input[name="delivery-method"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.toggleDeliveryAddress(e.target.value === 'delivery');
                this.calculateRental();
            });
        });
        
        // Click outside modal to close
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeBookingModal();
            }
        });
    }
    
    setMinDate() {
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const startDate = document.getElementById('rental-start');
        const endDate = document.getElementById('rental-end');
        
        if (startDate) {
            startDate.min = tomorrow.toISOString().split('T')[0];
        }
        
        if (endDate) {
            endDate.min = tomorrow.toISOString().split('T')[0];
        }
    }
    
    openBookingModal(product) {
        this.currentBooking = {
            product: product,
            startDate: null,
            endDate: null,
            quantity: 1,
            deliveryMethod: 'pickup',
            deliveryAddress: ''
        };
        
        // Update modal with product info
        const modal = document.getElementById('booking-modal');
        if (modal) {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // Update quantity options based on stock
        this.updateQuantityOptions(product.stock);
        
        // Reset form
        const form = document.getElementById('booking-form');
        if (form) {
            form.reset();
        }
        
        this.calculateRental();
    }
    
    closeBookingModal() {
        const modal = document.getElementById('booking-modal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        this.currentBooking = null;
    }
    
    updateQuantityOptions(maxStock) {
        const quantitySelect = document.getElementById('quantity');
        if (!quantitySelect) return;
        
        quantitySelect.innerHTML = '';
        
        const maxQuantity = Math.min(maxStock, 5); // สูงสุด 5 ชิ้น
        
        for (let i = 1; i <= maxQuantity; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `${i} ชิ้น`;
            quantitySelect.appendChild(option);
        }
    }
    
    toggleDeliveryAddress(show) {
        const addressSection = document.getElementById('delivery-address');
        if (addressSection) {
            addressSection.style.display = show ? 'block' : 'none';
            
            const addressField = document.getElementById('address');
            if (addressField) {
                addressField.required = show;
            }
        }
    }
    
    calculateRental() {
        if (!this.currentBooking) return;
        
        const startDate = document.getElementById('rental-start')?.value;
        const endDate = document.getElementById('rental-end')?.value;
        const quantity = parseInt(document.getElementById('quantity')?.value) || 1;
        const deliveryMethod = document.querySelector('input[name="delivery-method"]:checked')?.value || 'pickup';
        
        if (!startDate || !endDate) {
            this.updateRentalSummary(0, 0, 0, 0);
            return;
        }
        
        const start = new Date(startDate);
        const end = new Date(endDate);
        
        // ตรวจสอบวันที่
        if (end <= start) {
            this.showError('วันที่สิ้นสุดต้องมากกว่าวันที่เริ่มต้น');
            return;
        }
        
        const daysDiff = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
        
        if (daysDiff > this.maxRentalDays) {
            this.showError(`ระยะเวลาการเช่าสูงสุด ${this.maxRentalDays} วัน`);
            return;
        }
        
        // คำนวณราคา
        const dailyRate = this.currentBooking.product.dailyRate;
        const rentalCost = dailyRate * daysDiff * quantity;
        const deliveryCost = deliveryMethod === 'delivery' ? this.deliveryFee : 0;
        const totalCost = rentalCost + deliveryCost;
        
        this.updateRentalSummary(daysDiff, rentalCost, deliveryCost, totalCost);
        
        // อัปเดต currentBooking
        this.currentBooking.startDate = startDate;
        this.currentBooking.endDate = endDate;
        this.currentBooking.quantity = quantity;
        this.currentBooking.deliveryMethod = deliveryMethod;
        this.currentBooking.rentalCost = rentalCost;
        this.currentBooking.deliveryCost = deliveryCost;
        this.currentBooking.totalCost = totalCost;
    }
    
    updateRentalSummary(days, rentalCost, deliveryCost, totalCost) {
        const summary = document.getElementById('rental-summary');
        const rentalCostElement = document.getElementById('rental-cost');
        const deliveryCostElement = document.getElementById('delivery-cost');
        const totalCostElement = document.getElementById('total-cost');
        
        if (summary) {
            if (days > 0) {
                summary.innerHTML = `
                    <div class="summary-item">
                        <span>ระยะเวลาการเช่า: ${days} วัน</span>
                    </div>
                    <div class="summary-item">
                        <span>ค่าเช่าต่อวัน: ${app.formatPrice(this.currentBooking.product.dailyRate)}</span>
                    </div>
                `;
            } else {
                summary.innerHTML = '<p class="text-muted">กรุณาเลือกวันที่เช่า</p>';
            }
        }
        
        if (rentalCostElement) {
            rentalCostElement.textContent = app.formatPrice(rentalCost);
        }
        
        if (deliveryCostElement) {
            deliveryCostElement.textContent = app.formatPrice(deliveryCost);
        }
        
        if (totalCostElement) {
            totalCostElement.textContent = app.formatPrice(totalCost);
        }
    }
    
    async handleBookingSubmit(e) {
        e.preventDefault();
        
        if (!this.currentBooking || !this.currentBooking.startDate || !this.currentBooking.endDate) {
            this.showError('กรุณากรอกข้อมูลให้ครบถ้วน');
            return;
        }
        
        // ตรวจสอบการจัดส่ง
        if (this.currentBooking.deliveryMethod === 'delivery') {
            const address = document.getElementById('address')?.value.trim();
            if (!address) {
                this.showError('กรุณากรอกที่อยู่สำหรับจัดส่ง');
                return;
            }
            this.currentBooking.deliveryAddress = address;
        }
        
        // ตรวจสอบการเข้าสู่ระบบ
        const isLoggedIn = this.checkLoginStatus();
        if (!isLoggedIn) {
            if (confirm('กรุณาเข้าสู่ระบบก่อนทำการจอง\nต้องการไปหน้าเข้าสู่ระบบหรือไม่?')) {
                window.location.href = 'login.html';
            }
            return;
        }
        
        try {
            // แสดงการโหลด
            const submitBtn = e.target.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.textContent = 'กำลังจอง...';
            
            // จำลองการส่งข้อมูล
            await this.submitBooking(this.currentBooking);
            
            // แสดงความสำเร็จ
            this.showSuccess('จองสำเร็จแล้ว! เราจะติดต่อกลับภายใน 24 ชั่วโมง');
            
            // ปิด modal
            this.closeBookingModal();
            
            // รีเซ็ตปุ่ม
            submitBtn.disabled = false;
            submitBtn.textContent = originalText;
            
        } catch (error) {
            console.error('Booking error:', error);
            this.showError('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
        }
    }
    
    async submitBooking(bookingData) {
        // จำลองการส่งข้อมูลไปยัง API
        return new Promise((resolve) => {
            setTimeout(() => {
                // บันทึกลง localStorage สำหรับการทดสอบ
                const bookings = JSON.parse(localStorage.getItem('klonglens_bookings') || '[]');
                const newBooking = {
                    id: Date.now(),
                    ...bookingData,
                    bookingNumber: 'BK' + Date.now(),
                    status: 'pending',
                    createdAt: new Date().toISOString()
                };
                
                bookings.push(newBooking);
                localStorage.setItem('klonglens_bookings', JSON.stringify(bookings));
                
                resolve(newBooking);
            }, 1500);
        });
    }
    
    checkLoginStatus() {
        // จำลองการตรวจสอบสถานะการเข้าสู่ระบบ
        return localStorage.getItem('klonglens_user_logged_in') === 'true';
    }
    
    showSuccess(message) {
        // สร้าง notification แสดงความสำเร็จ
        const notification = document.createElement('div');
        notification.className = 'notification success';
        notification.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        `;
        
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background-color: #4CAF50;
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            z-index: 10001;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideInRight 0.3s ease;
            max-width: 350px;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
    
    showError(message) {
        // สร้าง notification แสดงข้อผิดพลาด
        const notification = document.createElement('div');
        notification.className = 'notification error';
        notification.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <span>${message}</span>
        `;
        
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background-color: #f44336;
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            z-index: 10001;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideInRight 0.3s ease;
            max-width: 350px;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }
}

// Initialize booking system
const bookingSystem = new BookingSystem();

// Export for global access
window.BookingSystem = BookingSystem;
window.bookingSystem = bookingSystem;
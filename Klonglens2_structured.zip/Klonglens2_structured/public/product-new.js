// Product Detail Page JavaScript
class ProductDetail {
    constructor() {
        this.currentProduct = null;
        this.selectedImageIndex = 0;
        this.init();
    }

    init() {
        this.loadProductFromURL();
        this.bindEvents();
    }

    loadProductFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        const productId = urlParams.get('id');
        
        if (!productId) {
            this.showError('ไม่พบข้อมูลสินค้า');
            return;
        }

        this.currentProduct = ProductService.getProductById(productId);
        
        if (!this.currentProduct) {
            this.showError('ไม่พบสินค้าที่ต้องการ');
            return;
        }

        this.renderProduct();
        this.loadProductReviews(productId);
        
        // Store current product globally for other scripts
        window.currentProduct = this.currentProduct;
    }

    renderProduct() {
        const container = document.getElementById('product-detail');
        if (!container) return;

        const product = this.currentProduct;
        const isOutOfStock = !product.availability || product.stock <= 0;
        
        // Create image gallery
        const images = [product.image]; // เพิ่ม gallery_images ถ้ามี
        
        container.innerHTML = `
            <div class="product-layout">
                <div class="product-images">
                    <div class="main-image">
                        <img src="${images[this.selectedImageIndex]}" alt="${product.name}" id="main-product-image">
                        ${isOutOfStock ? '<div class="stock-overlay">หมด</div>' : ''}
                    </div>
                    
                    ${images.length > 1 ? `
                        <div class="thumbnail-images">
                            ${images.map((img, index) => `
                                <img src="${img}" alt="${product.name}" 
                                     class="thumbnail ${index === this.selectedImageIndex ? 'active' : ''}"
                                     onclick="productDetail.selectImage(${index})">
                            `).join('')}
                        </div>
                    ` : ''}
                </div>

                <div class="product-info">
                    <div class="product-header">
                        <div class="product-brand">${product.brand}</div>
                        <h1 class="product-name">${product.name}</h1>
                        
                        <div class="product-rating">
                            <div class="stars">
                                ${this.renderStars(product.rating || 0)}
                                <span class="rating-text">${(product.rating || 0).toFixed(1)}</span>
                            </div>
                            <div class="review-count">
                                (${product.reviewCount || 0} รีวิว)
                                <button class="view-reviews-btn" onclick="document.getElementById('reviews-section').scrollIntoView()">
                                    ดูรีวิวทั้งหมด
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="product-pricing">
                        <div class="price-display">
                            <span class="daily-rate">${app.formatPrice(product.dailyRate)}</span>
                            <span class="price-unit">/วัน</span>
                        </div>
                        
                        ${product.weeklyRate ? `
                            <div class="price-option">
                                <span class="weekly-rate">${app.formatPrice(product.weeklyRate)}/สัปดาห์</span>
                                <span class="savings">ประหยัด ${Math.round((1 - (product.weeklyRate / (product.dailyRate * 7))) * 100)}%</span>
                            </div>
                        ` : ''}
                        
                        ${product.monthlyRate ? `
                            <div class="price-option">
                                <span class="monthly-rate">${app.formatPrice(product.monthlyRate)}/เดือน</span>
                                <span class="savings">ประหยัด ${Math.round((1 - (product.monthlyRate / (product.dailyRate * 30))) * 100)}%</span>
                            </div>
                        ` : ''}
                    </div>

                    <div class="product-availability">
                        <div class="stock-info ${isOutOfStock ? 'out-of-stock' : ''}">
                            <i class="fas fa-box"></i>
                            ${isOutOfStock ? 'สินค้าหมด' : `มีในสต็อก ${product.stock} ชิ้น`}
                        </div>
                    </div>

                    <div class="product-actions">
                        <button class="rent-now-btn ${isOutOfStock ? 'disabled' : ''}" 
                                onclick="${isOutOfStock ? '' : 'bookingSystem.openBookingModal(currentProduct)'}" 
                                ${isOutOfStock ? 'disabled' : ''}>
                            <i class="fas fa-calendar-alt"></i>
                            ${isOutOfStock ? 'สินค้าหมด' : 'จองเช่าเลย'}
                        </button>
                        
                        <button class="add-to-cart-btn ${isOutOfStock ? 'disabled' : ''}" 
                                onclick="${isOutOfStock ? '' : 'app.addToCart(currentProduct)'}" 
                                ${isOutOfStock ? 'disabled' : ''}>
                            <i class="fas fa-cart-plus"></i>
                            ${isOutOfStock ? 'สินค้าหมด' : 'เพิ่มลงตะกร้า'}
                        </button>
                        
                        <button class="write-review-btn" onclick="reviewsSystem.openReviewModal(currentProduct)">
                            <i class="fas fa-star"></i>
                            เขียนรีวิว
                        </button>
                    </div>

                    <div class="product-specs">
                        <h3>ข้อมูลเฉพาะ</h3>
                        <div class="specs-grid">
                            ${product.specs ? Object.entries(product.specs).map(([key, value]) => `
                                <div class="spec-item">
                                    <span class="spec-label">${this.translateSpec(key)}:</span>
                                    <span class="spec-value">${value}</span>
                                </div>
                            `).join('') : '<p>ไม่มีข้อมูลสเปค</p>'}
                        </div>
                    </div>

                    ${product.features && product.features.length > 0 ? `
                        <div class="product-features">
                            <h3>คุณสมบัติเด่น</h3>
                            <ul class="features-list">
                                ${product.features.map(feature => `
                                    <li><i class="fas fa-check"></i> ${feature}</li>
                                `).join('')}
                            </ul>
                        </div>
                    ` : ''}
                </div>
            </div>

            <!-- Product Description -->
            <div class="product-description">
                <h3>รายละเอียดสินค้า</h3>
                <p>${product.description || 'รายละเอียดเพิ่มเติมจะอัปเดตเร็วๆ นี้'}</p>
            </div>

            <!-- Reviews Section -->
            <div class="reviews-section" id="reviews-section">
                <div class="reviews-header">
                    <h3>รีวิวจากลูกค้า</h3>
                    <button class="write-review-btn-secondary" onclick="reviewsSystem.openReviewModal(currentProduct)">
                        <i class="fas fa-edit"></i>
                        เขียนรีวิว
                    </button>
                </div>
                
                <div class="reviews-summary" id="reviews-summary">
                    <!-- Reviews summary will be loaded here -->
                </div>
                
                <div class="reviews-list" id="reviews-list">
                    <!-- Reviews will be loaded here -->
                </div>
            </div>

            <!-- Related Products -->
            <div class="related-products">
                <h3>สินค้าที่เกี่ยวข้อง</h3>
                <div class="related-products-grid" id="related-products">
                    <!-- Related products will be loaded here -->
                </div>
            </div>
        `;

        // Update breadcrumb
        this.updateBreadcrumb();
        
        // Load related products
        this.loadRelatedProducts();
    }

    selectImage(index) {
        this.selectedImageIndex = index;
        
        // Update main image
        const mainImage = document.getElementById('main-product-image');
        if (mainImage) {
            const images = [this.currentProduct.image]; // Add more images if available
            mainImage.src = images[index];
        }
        
        // Update thumbnail active state
        document.querySelectorAll('.thumbnail').forEach((thumb, i) => {
            thumb.classList.toggle('active', i === index);
        });
    }

    updateBreadcrumb() {
        const breadcrumb = document.getElementById('breadcrumb');
        if (breadcrumb && this.currentProduct) {
            const categoryNames = {
                'camera': 'กล้อง',
                'lens': 'เลนส์',
                'accessory': 'อุปกรณ์เสริม'
            };
            
            const categoryName = categoryNames[this.currentProduct.category] || 'สินค้า';
            
            breadcrumb.innerHTML = `
                <a href="index.html">หน้าแรก</a>
                <span><i class="fas fa-chevron-right"></i></span>
                <a href="search.html?category=${this.currentProduct.category}">${categoryName}</a>
                <span><i class="fas fa-chevron-right"></i></span>
                <span class="current">${this.currentProduct.name}</span>
            `;
        }
    }

    loadProductReviews(productId) {
        const reviews = reviewsSystem.loadProductReviews(productId);
        
        // Render reviews summary
        this.renderReviewsSummary(reviews);
        
        // Render reviews list
        reviewsSystem.renderReviews(reviews, 'reviews-list');
    }

    renderReviewsSummary(reviews) {
        const summaryContainer = document.getElementById('reviews-summary');
        if (!summaryContainer) return;

        if (reviews.length === 0) {
            summaryContainer.innerHTML = `
                <div class="no-reviews-summary">
                    <p>ยังไม่มีรีวิวสำหรับสินค้านี้</p>
                </div>
            `;
            return;
        }

        const averageRating = reviewsSystem.calculateAverageRating(reviews);
        const distribution = reviewsSystem.getRatingDistribution(reviews);
        const totalReviews = reviews.length;

        summaryContainer.innerHTML = `
            <div class="rating-overview">
                <div class="average-rating">
                    <span class="rating-number">${averageRating}</span>
                    <div class="rating-stars">
                        ${reviewsSystem.renderStars(parseFloat(averageRating))}
                    </div>
                    <span class="total-reviews">จาก ${totalReviews} รีวิว</span>
                </div>
                
                <div class="rating-distribution">
                    ${[5, 4, 3, 2, 1].map(star => {
                        const count = distribution[star];
                        const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0;
                        return `
                            <div class="rating-bar">
                                <span class="rating-label">${star} ดาว</span>
                                <div class="bar-container">
                                    <div class="bar-fill" style="width: ${percentage}%"></div>
                                </div>
                                <span class="rating-count">${count}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    }

    loadRelatedProducts() {
        if (!this.currentProduct) return;

        // หาสินค้าที่เกี่ยวข้อง (ยี่ห้อเดียวกันหรือหมวดหมู่เดียวกัน)
        const allProducts = ProductService.getAllProducts();
        let relatedProducts = allProducts.filter(product => 
            product.id !== this.currentProduct.id && (
                product.brand === this.currentProduct.brand || 
                product.category === this.currentProduct.category
            )
        );

        // จำกัดจำนวนและสุ่มเรียง
        relatedProducts = relatedProducts
            .sort(() => Math.random() - 0.5)
            .slice(0, 4);

        const container = document.getElementById('related-products');
        if (!container) return;

        if (relatedProducts.length === 0) {
            container.innerHTML = '<p>ไม่มีสินค้าที่เกี่ยวข้อง</p>';
            return;
        }

        container.innerHTML = relatedProducts.map(product => {
            const isOutOfStock = !product.availability || product.stock <= 0;
            
            return `
                <div class="product-card" onclick="window.location.href='product.html?id=${product.id}'">
                    <div class="product-image">
                        <img src="${product.image}" alt="${product.name}">
                        ${isOutOfStock ? '<div class="stock-overlay">หมด</div>' : ''}
                    </div>
                    
                    <div class="product-info">
                        <div class="product-brand">${product.brand}</div>
                        <h4 class="product-name">${product.name}</h4>
                        
                        <div class="product-rating">
                            ${this.renderStars(product.rating || 0)}
                            <span class="rating-count">(${product.reviewCount || 0})</span>
                        </div>
                        
                        <div class="product-price">
                            ${app.formatPrice(product.dailyRate)}/วัน
                        </div>
                        
                        <button class="add-to-cart ${isOutOfStock ? 'disabled' : ''}" 
                                onclick="event.stopPropagation(); ${isOutOfStock ? '' : 'app.addToCart(' + JSON.stringify(product).replace(/"/g, '&quot;') + ')'}" 
                                ${isOutOfStock ? 'disabled' : ''}>
                            ${isOutOfStock ? 'สินค้าหมด' : 'เพิ่มลงตะกร้า'}
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    renderStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        
        let starsHTML = '';
        
        // Full stars
        for (let i = 0; i < fullStars; i++) {
            starsHTML += '<i class="fas fa-star"></i>';
        }
        
        // Half star
        if (hasHalfStar) {
            starsHTML += '<i class="fas fa-star-half-alt"></i>';
        }
        
        // Empty stars
        for (let i = 0; i < emptyStars; i++) {
            starsHTML += '<i class="far fa-star"></i>';
        }
        
        return starsHTML;
    }

    translateSpec(specKey) {
        const translations = {
            'sensor': 'เซนเซอร์',
            'resolution': 'ความละเอียด',
            'videoRecording': 'การบันทึกวิดีโอ',
            'mount': 'ขาจับ',
            'weight': 'น้ำหนัก',
            'focalLength': 'ความยาวโฟกัส',
            'aperture': 'ค่ารูรับแสง',
            'filterSize': 'ขนาดฟิลเตอร์',
            'material': 'วัสดุ',
            'maxHeight': 'ความสูงสูงสุด',
            'minHeight': 'ความสูงต่ำสุด',
            'maxLoad': 'น้ำหนักสูงสุด',
            'type': 'ประเภท',
            'range': 'ระยะการทำงาน',
            'batteryLife': 'อายุแบตเตอรี่',
            'channels': 'ช่องสัญญาณ',
            'power': 'กำลังไฟ',
            'colorTemp': 'อุณหภูมิสี',
            'cri': 'CRI',
            'control': 'การควบคุม'
        };
        
        return translations[specKey] || specKey;
    }

    bindEvents() {
        // Any additional event bindings can go here
    }

    showError(message) {
        const container = document.getElementById('product-detail');
        if (container) {
            container.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h2>${message}</h2>
                    <p>กลับไปหน้าแรกหรือลองค้นหาสินค้าอื่น</p>
                    <a href="index.html" class="btn-primary">กลับหน้าแรก</a>
                </div>
            `;
        }
    }
}

// Initialize product detail
let productDetail;
document.addEventListener('DOMContentLoaded', () => {
    productDetail = new ProductDetail();
    window.productDetail = productDetail;
});
// Search and Filter JavaScript for Klonglens
class ProductSearch {
    constructor() {
        this.currentFilters = {
            query: '',
            category: '',
            brands: [],
            minPrice: null,
            maxPrice: null,
            inStock: true,
            featured: false,
            sortBy: ''
        };
        
        this.currentPage = 1;
        this.itemsPerPage = 12;
        this.currentView = 'grid';
        this.allProducts = [];
        this.filteredProducts = [];
        
        this.init();
    }
    
    init() {
        this.loadProducts();
        this.bindEvents();
        this.updateFromURL();
    }
    
    loadProducts() {
        // โหลดข้อมูลสินค้าจาก ProductService
        this.allProducts = ProductService.getAllProducts();
        this.applyFilters();
    }
    
    bindEvents() {
        // Search input
        const searchInput = document.getElementById('search-input');
        const searchBtn = document.getElementById('search-btn');
        
        if (searchBtn) {
            searchBtn.addEventListener('click', () => this.performSearch());
        }
        
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.performSearch();
                }
            });
            
            // Real-time search with debounce
            let searchTimeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.currentFilters.query = e.target.value.trim();
                    this.currentPage = 1;
                    this.applyFilters();
                    this.updateURL();
                }, 500);
            });
        }
        
        // Category filters (radio buttons)
        document.querySelectorAll('input[name="category"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.currentFilters.category = e.target.value;
                this.currentPage = 1;
                this.applyFilters();
                this.updateBrandTabs();
                this.updateURL();
            });
        });
        
        // Brand filters (checkboxes)
        document.querySelectorAll('input[type="checkbox"][value]').forEach(checkbox => {
            if (['Canon', 'Nikon', 'Sony', 'Manfrotto', 'RODE', 'Godox'].includes(checkbox.value)) {
                checkbox.addEventListener('change', (e) => {
                    const brand = e.target.value;
                    if (e.target.checked) {
                        if (!this.currentFilters.brands.includes(brand)) {
                            this.currentFilters.brands.push(brand);
                        }
                    } else {
                        this.currentFilters.brands = this.currentFilters.brands.filter(b => b !== brand);
                    }
                    this.currentPage = 1;
                    this.applyFilters();
                    this.updateURL();
                });
            }
        });
        
        // Price range filters
        const minPriceInput = document.getElementById('min-price');
        const maxPriceInput = document.getElementById('max-price');
        
        [minPriceInput, maxPriceInput].forEach(input => {
            if (input) {
                input.addEventListener('change', () => {
                    this.currentFilters.minPrice = minPriceInput.value ? parseInt(minPriceInput.value) : null;
                    this.currentFilters.maxPrice = maxPriceInput.value ? parseInt(maxPriceInput.value) : null;
                    this.currentPage = 1;
                    this.applyFilters();
                    this.updateURL();
                });
            }
        });
        
        // Price suggestion buttons
        document.querySelectorAll('.price-tag').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const min = e.target.dataset.min;
                const max = e.target.dataset.max;
                
                if (minPriceInput) minPriceInput.value = min || '';
                if (maxPriceInput) maxPriceInput.value = max || '';
                
                this.currentFilters.minPrice = min ? parseInt(min) : null;
                this.currentFilters.maxPrice = max ? parseInt(max) : null;
                
                // Update active state
                document.querySelectorAll('.price-tag').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                
                this.currentPage = 1;
                this.applyFilters();
                this.updateURL();
            });
        });
        
        // Other filters
        const inStockFilter = document.getElementById('in-stock');
        const featuredFilter = document.getElementById('featured');
        
        if (inStockFilter) {
            inStockFilter.addEventListener('change', (e) => {
                this.currentFilters.inStock = e.target.checked;
                this.currentPage = 1;
                this.applyFilters();
                this.updateURL();
            });
        }
        
        if (featuredFilter) {
            featuredFilter.addEventListener('change', (e) => {
                this.currentFilters.featured = e.target.checked;
                this.currentPage = 1;
                this.applyFilters();
                this.updateURL();
            });
        }
        
        // Sort options
        const sortSelect = document.getElementById('sort-select');
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                this.currentFilters.sortBy = e.target.value;
                this.applyFilters();
                this.updateURL();
            });
        }
        
        // View options
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                
                this.currentView = e.target.dataset.view;
                this.renderProducts();
            });
        });
        
        // Category tabs
        document.querySelectorAll('.cat-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                document.querySelectorAll('.cat-tab').forEach(t => t.classList.remove('active'));
                e.target.classList.add('active');
                
                this.currentFilters.category = e.target.dataset.category;
                
                // Update radio button
                const radio = document.querySelector(`input[name="category"][value="${e.target.dataset.category}"]`);
                if (radio) radio.checked = true;
                
                this.currentPage = 1;
                this.applyFilters();
                this.updateBrandTabs();
                this.updateURL();
            });
        });
        
        // Clear filters
        const clearFiltersBtn = document.getElementById('clear-filters');
        if (clearFiltersBtn) {
            clearFiltersBtn.addEventListener('click', () => {
                this.clearAllFilters();
            });
        }
    }
    
    performSearch() {
        const searchInput = document.getElementById('search-input');
        const query = searchInput?.value.trim() || '';
        
        this.currentFilters.query = query;
        this.currentPage = 1;
        this.applyFilters();
        this.updateURL();
    }
    
    applyFilters() {
        // ใช้ ProductService ในการค้นหาและกรอง
        const filters = {
            category: this.currentFilters.category,
            brand: this.currentFilters.brands.length > 0 ? this.currentFilters.brands[0] : null, // ใช้ยี่ห้อแรก
            minPrice: this.currentFilters.minPrice,
            maxPrice: this.currentFilters.maxPrice,
            inStock: this.currentFilters.inStock,
            sortBy: this.currentFilters.sortBy
        };
        
        this.filteredProducts = ProductService.searchProducts(this.currentFilters.query, filters);
        
        // กรองเพิ่มเติมสำหรับ brands หลายค่าย และ featured
        if (this.currentFilters.brands.length > 1) {
            this.filteredProducts = this.filteredProducts.filter(product => 
                this.currentFilters.brands.includes(product.brand)
            );
        }
        
        if (this.currentFilters.featured) {
            this.filteredProducts = this.filteredProducts.filter(product => product.is_featured);
        }
        
        this.renderProducts();
        this.updateResultsInfo();
        this.renderPagination();
    }
    
    renderProducts() {
        const productsGrid = document.getElementById('products-grid');
        if (!productsGrid) return;
        
        // คำนวณสินค้าสำหรับหน้าปัจจุบัน
        const startIndex = (this.currentPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const productsToShow = this.filteredProducts.slice(startIndex, endIndex);
        
        if (productsToShow.length === 0) {
            productsGrid.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h3>ไม่พบสินค้าที่ตรงกับเงื่อนไขการค้นหา</h3>
                    <p>ลองเปลี่ยนเงื่อนไขการค้นหาหรือลบตัวกรองบางส่วน</p>
                    <button class="clear-filters-btn" onclick="productSearch.clearAllFilters()">ลบตัวกรองทั้งหมด</button>
                </div>
            `;
            return;
        }
        
        // เปลี่ยน class ตาม view mode
        productsGrid.className = `products-grid ${this.currentView}-view`;
        
        const productsHTML = productsToShow.map(product => {
            const isOutOfStock = !product.availability || product.stock <= 0;
            const stockClass = isOutOfStock ? 'out-of-stock' : '';
            
            return `
                <div class="product-card ${stockClass}" onclick="window.location.href='product.html?id=${product.id}'">
                    <div class="product-image">
                        <img src="${product.image}" alt="${product.name}">
                        ${isOutOfStock ? '<div class="stock-overlay">หมด</div>' : ''}
                        ${product.is_featured ? '<div class="featured-badge">แนะนำ</div>' : ''}
                    </div>
                    
                    <div class="product-info">
                        <div class="product-brand">${product.brand}</div>
                        <h3 class="product-name">${product.name}</h3>
                        
                        ${this.currentView === 'list' ? `
                            <p class="product-description">${product.specs ? Object.entries(product.specs).slice(0, 2).map(([key, value]) => `${key}: ${value}`).join(' • ') : ''}</p>
                        ` : ''}
                        
                        <div class="product-rating">
                            ${'★'.repeat(Math.floor(product.rating || 0))}${'☆'.repeat(5 - Math.floor(product.rating || 0))}
                            <span class="rating-count">(${product.reviewCount || 0})</span>
                        </div>
                        
                        <div class="product-price">
                            ${app.formatPrice(product.dailyRate)}/วัน
                        </div>
                        
                        <div class="product-stock">
                            <i class="fas fa-box"></i>
                            เหลือ ${product.stock} ชิ้น
                        </div>
                        
                        <button class="add-to-cart ${isOutOfStock ? 'disabled' : ''}" 
                                onclick="event.stopPropagation(); ${isOutOfStock ? '' : `app.addToCart(${JSON.stringify(product).replace(/"/g, '&quot;')})`}" 
                                ${isOutOfStock ? 'disabled' : ''}>
                            ${isOutOfStock ? 'สินค้าหมด' : 'เพิ่มลงตะกร้า'}
                        </button>
                    </div>
                </div>
            `;
        }).join('');
        
        productsGrid.innerHTML = productsHTML;
    }
    
    updateResultsInfo() {
        const resultsCount = document.getElementById('results-count');
        if (resultsCount) {
            const total = this.filteredProducts.length;
            const startIndex = (this.currentPage - 1) * this.itemsPerPage + 1;
            const endIndex = Math.min(startIndex + this.itemsPerPage - 1, total);
            
            if (total === 0) {
                resultsCount.textContent = 'ไม่พบสินค้า';
            } else {
                resultsCount.textContent = `แสดง ${startIndex}-${endIndex} จาก ${total} รายการ`;
            }
        }
        
        // Update page title
        const searchTitle = document.getElementById('search-title');
        if (searchTitle) {
            if (this.currentFilters.query) {
                searchTitle.textContent = `ผลการค้นหา "${this.currentFilters.query}"`;
            } else if (this.currentFilters.category) {
                const categoryNames = {
                    'camera': 'กล้อง',
                    'lens': 'เลนส์',
                    'accessory': 'อุปกรณ์เสริม'
                };
                searchTitle.textContent = categoryNames[this.currentFilters.category] || 'ผลการค้นหา';
            } else {
                searchTitle.textContent = 'สินค้าทั้งหมด';
            }
        }
    }
    
    renderPagination() {
        const pagination = document.getElementById('pagination');
        if (!pagination) return;
        
        const totalPages = Math.ceil(this.filteredProducts.length / this.itemsPerPage);
        
        if (totalPages <= 1) {
            pagination.style.display = 'none';
            return;
        }
        
        pagination.style.display = 'flex';
        
        const pageNumbers = document.getElementById('page-numbers');
        const prevBtn = document.getElementById('prev-page');
        const nextBtn = document.getElementById('next-page');
        
        // Previous button
        if (prevBtn) {
            prevBtn.disabled = this.currentPage === 1;
            prevBtn.onclick = () => {
                if (this.currentPage > 1) {
                    this.currentPage--;
                    this.renderProducts();
                    this.updateResultsInfo();
                    this.renderPagination();
                    this.scrollToTop();
                }
            };
        }
        
        // Next button
        if (nextBtn) {
            nextBtn.disabled = this.currentPage === totalPages;
            nextBtn.onclick = () => {
                if (this.currentPage < totalPages) {
                    this.currentPage++;
                    this.renderProducts();
                    this.updateResultsInfo();
                    this.renderPagination();
                    this.scrollToTop();
                }
            };
        }
        
        // Page numbers
        if (pageNumbers) {
            const pageNumbersHTML = [];
            const maxVisiblePages = 5;
            let startPage = Math.max(1, this.currentPage - Math.floor(maxVisiblePages / 2));
            let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
            
            // Adjust startPage if we're near the end
            if (endPage - startPage + 1 < maxVisiblePages) {
                startPage = Math.max(1, endPage - maxVisiblePages + 1);
            }
            
            for (let i = startPage; i <= endPage; i++) {
                pageNumbersHTML.push(`
                    <button class="page-num ${i === this.currentPage ? 'active' : ''}" 
                            onclick="productSearch.goToPage(${i})">${i}</button>
                `);
            }
            
            pageNumbers.innerHTML = pageNumbersHTML.join('');
        }
    }
    
    goToPage(page) {
        this.currentPage = page;
        this.renderProducts();
        this.updateResultsInfo();
        this.renderPagination();
        this.scrollToTop();
    }
    
    scrollToTop() {
        document.querySelector('.results-area').scrollIntoView({ behavior: 'smooth' });
    }
    
    updateBrandTabs() {
        const brandTabs = document.getElementById('brand-tabs');
        if (!brandTabs) return;
        
        if (!this.currentFilters.category || this.currentFilters.category === '') {
            brandTabs.style.display = 'none';
            return;
        }
        
        // Get available brands for current category
        const categoryProducts = this.allProducts.filter(p => 
            !this.currentFilters.category || p.category === this.currentFilters.category
        );
        
        const availableBrands = [...new Set(categoryProducts.map(p => p.brand))];
        
        if (availableBrands.length <= 1) {
            brandTabs.style.display = 'none';
            return;
        }
        
        brandTabs.style.display = 'flex';
        brandTabs.innerHTML = availableBrands.map(brand => `
            <button class="brand-tab ${this.currentFilters.brands.includes(brand) ? 'active' : ''}" 
                    onclick="productSearch.toggleBrand('${brand}')">${brand}</button>
        `).join('');
    }
    
    toggleBrand(brand) {
        const index = this.currentFilters.brands.indexOf(brand);
        if (index > -1) {
            this.currentFilters.brands.splice(index, 1);
        } else {
            this.currentFilters.brands.push(brand);
        }
        
        // Update checkbox
        const checkbox = document.querySelector(`input[type="checkbox"][value="${brand}"]`);
        if (checkbox) {
            checkbox.checked = this.currentFilters.brands.includes(brand);
        }
        
        this.currentPage = 1;
        this.applyFilters();
        this.updateBrandTabs();
        this.updateURL();
    }
    
    clearAllFilters() {
        // Reset filters
        this.currentFilters = {
            query: '',
            category: '',
            brands: [],
            minPrice: null,
            maxPrice: null,
            inStock: true,
            featured: false,
            sortBy: ''
        };
        
        this.currentPage = 1;
        
        // Reset UI elements
        const searchInput = document.getElementById('search-input');
        if (searchInput) searchInput.value = '';
        
        document.querySelectorAll('input[name="category"]').forEach(radio => {
            radio.checked = radio.value === '';
        });
        
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            if (checkbox.id === 'in-stock') {
                checkbox.checked = true;
            } else {
                checkbox.checked = false;
            }
        });
        
        const minPriceInput = document.getElementById('min-price');
        const maxPriceInput = document.getElementById('max-price');
        if (minPriceInput) minPriceInput.value = '';
        if (maxPriceInput) maxPriceInput.value = '';
        
        const sortSelect = document.getElementById('sort-select');
        if (sortSelect) sortSelect.value = '';
        
        document.querySelectorAll('.cat-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.category === '');
        });
        
        document.querySelectorAll('.price-tag').forEach(tag => {
            tag.classList.remove('active');
        });
        
        this.applyFilters();
        this.updateBrandTabs();
        this.updateURL();
    }
    
    updateFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        
        // Update filters from URL parameters
        if (urlParams.get('q')) {
            this.currentFilters.query = urlParams.get('q');
            const searchInput = document.getElementById('search-input');
            if (searchInput) searchInput.value = this.currentFilters.query;
        }
        
        if (urlParams.get('category')) {
            this.currentFilters.category = urlParams.get('category');
            const radio = document.querySelector(`input[name="category"][value="${this.currentFilters.category}"]`);
            if (radio) radio.checked = true;
        }
        
        if (urlParams.get('brand')) {
            this.currentFilters.brands = urlParams.get('brand').split(',');
        }
        
        if (urlParams.get('min_price')) {
            this.currentFilters.minPrice = parseInt(urlParams.get('min_price'));
        }
        
        if (urlParams.get('max_price')) {
            this.currentFilters.maxPrice = parseInt(urlParams.get('max_price'));
        }
        
        if (urlParams.get('page')) {
            this.currentPage = parseInt(urlParams.get('page')) || 1;
        }
        
        this.applyFilters();
    }
    
    updateURL() {
        const url = new URL(window.location);
        
        // Update URL parameters
        if (this.currentFilters.query) {
            url.searchParams.set('q', this.currentFilters.query);
        } else {
            url.searchParams.delete('q');
        }
        
        if (this.currentFilters.category) {
            url.searchParams.set('category', this.currentFilters.category);
        } else {
            url.searchParams.delete('category');
        }
        
        if (this.currentFilters.brands.length > 0) {
            url.searchParams.set('brand', this.currentFilters.brands.join(','));
        } else {
            url.searchParams.delete('brand');
        }
        
        if (this.currentFilters.minPrice) {
            url.searchParams.set('min_price', this.currentFilters.minPrice);
        } else {
            url.searchParams.delete('min_price');
        }
        
        if (this.currentFilters.maxPrice) {
            url.searchParams.set('max_price', this.currentFilters.maxPrice);
        } else {
            url.searchParams.delete('max_price');
        }
        
        if (this.currentPage > 1) {
            url.searchParams.set('page', this.currentPage);
        } else {
            url.searchParams.delete('page');
        }
        
        // Update URL without refreshing page
        window.history.replaceState({}, '', url);
    }
}

// Initialize search when page loads
let productSearch;
document.addEventListener('DOMContentLoaded', () => {
    productSearch = new ProductSearch();
});

// Export for global access
window.ProductSearch = ProductSearch;
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ProductSearch;
}
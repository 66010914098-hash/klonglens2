// Categories page functionality
class CategoriesPage {
    constructor() {
        this.categories = this.getCategoriesData();
        this.init();
    }

    init() {
        this.initCategoryInteractions();
        this.addLoadingAnimation();
    }

    // Categories data
    getCategoriesData() {
        return {
            camera: {
                name: 'กล้อง',
                description: 'กล้องดิจิทัลและกล้องฟิล์ม',
                count: 120,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop'
            },
            lens: {
                name: 'เลนส์',
                description: 'เลนส์หลากหลายรูปแบบ',
                count: 80,
                image: 'https://images.unsplash.com/photo-1606983340077-882fe2c049c8?w=400&h=300&fit=crop'
            },
            mirrorless: {
                name: 'Mirrorless',
                description: 'กล้องไม่มีกระจกสะท้อน',
                count: 65,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop'
            },
            dslr: {
                name: 'DSLR',
                description: 'กล้องรีเฟลกซ์ดิจิทัล',
                count: 45,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop'
            },
            gopro: {
                name: 'GoPro',
                description: 'กล้องแอคชั่น กันน้ำ กันสั่น',
                count: 25,
                image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=300&fit=crop'
            },
            actioncam: {
                name: 'ActionCam',
                description: 'กล้องสำหรับกิจกรรมกีฬา',
                count: 30,
                image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=300&fit=crop'
            },
            compact: {
                name: 'Compact',
                description: 'กล้องคอมแปคต์พกพา',
                count: 35,
                image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=300&fit=crop'
            },
            accessories: {
                name: 'อุปกรณ์เสริม',
                description: 'ขาตั้ง สายสะพาย เลนส์ฟิลเตอร์',
                count: 100,
                image: 'https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=400&h=300&fit=crop'
            },
            lighting: {
                name: 'อุปกรณ์แสง',
                description: 'ไฟสตูดิโอ แสงสตรอบ',
                count: 40,
                image: 'https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=400&h=300&fit=crop'
            }
        };
    }

    // Initialize category interactions
    initCategoryInteractions() {
        const categoryCards = document.querySelectorAll('.category-card-main');
        
        categoryCards.forEach(card => {
            card.addEventListener('click', () => {
                const categoryType = card.dataset.category;
                this.navigateToCategory(categoryType);
            });
            
            // Add hover effects
            card.addEventListener('mouseenter', () => {
                this.animateCard(card, 'enter');
            });
            
            card.addEventListener('mouseleave', () => {
                this.animateCard(card, 'leave');
            });
        });
    }

    // Navigate to category products page
    navigateToCategory(categoryType) {
        const category = this.categories[categoryType];
        if (category) {
            // Store selected category in session storage
            sessionStorage.setItem('selectedCategory', JSON.stringify({
                type: categoryType,
                name: category.name,
                description: category.description
            }));
            
            // Navigate to category products page
            window.location.href = `category.html?type=${categoryType}`;
        }
    }

    // Animate card interactions
    animateCard(card, action) {
        const image = card.querySelector('.category-image img');
        const content = card.querySelector('.category-content');
        
        if (action === 'enter') {
            // Subtle animation on hover
            card.style.transform = 'translateY(-10px) scale(1.02)';
            if (image) {
                image.style.transform = 'scale(1.1)';
            }
        } else {
            // Reset animation
            card.style.transform = 'translateY(0) scale(1)';
            if (image) {
                image.style.transform = 'scale(1)';
            }
        }
    }

    // Add loading animation
    addLoadingAnimation() {
        const cards = document.querySelectorAll('.category-card-main');
        
        cards.forEach((card, index) => {
            // Add fade-in animation with staggered delay
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }

    // Show loading skeleton
    showLoadingSkeleton() {
        const container = document.querySelector('.categories-grid-main');
        if (!container) return;
        
        container.innerHTML = '';
        
        // Create skeleton cards
        for (let i = 0; i < 9; i++) {
            const skeletonCard = document.createElement('div');
            skeletonCard.className = 'skeleton-card';
            skeletonCard.innerHTML = `
                <div class="skeleton-image"></div>
                <div class="skeleton-content">
                    <div class="skeleton-text title"></div>
                    <div class="skeleton-text description"></div>
                    <div class="skeleton-text count"></div>
                </div>
            `;
            container.appendChild(skeletonCard);
        }
    }

    // Show empty state
    showEmptyState() {
        const container = document.querySelector('.categories-grid-main');
        if (!container) return;
        
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-camera"></i>
                <h3>ไม่พบหมวดหมู่</h3>
                <p>ขออภัย ไม่สามารถโหลดหมวดหมู่ได้ในขณะนี้</p>
                <a href="index.html" class="auth-btn">กลับหน้าแรก</a>
            </div>
        `;
    }

    // Search categories
    searchCategories(query) {
        const cards = document.querySelectorAll('.category-card-main');
        const searchTerm = query.toLowerCase();
        let visibleCount = 0;
        
        cards.forEach(card => {
            const categoryType = card.dataset.category;
            const category = this.categories[categoryType];
            
            if (category) {
                const isMatch = category.name.toLowerCase().includes(searchTerm) ||
                               category.description.toLowerCase().includes(searchTerm) ||
                               categoryType.toLowerCase().includes(searchTerm);
                
                if (isMatch || !searchTerm) {
                    card.style.display = 'block';
                    visibleCount++;
                } else {
                    card.style.display = 'none';
                }
            }
        });
        
        // Show empty state if no results
        if (visibleCount === 0 && searchTerm) {
            this.showNoSearchResults(searchTerm);
        }
    }

    // Show no search results
    showNoSearchResults(query) {
        const container = document.querySelector('.categories-grid-main');
        if (!container) return;
        
        const emptyState = document.createElement('div');
        emptyState.className = 'empty-state';
        emptyState.innerHTML = `
            <i class="fas fa-search"></i>
            <h3>ไม่พบผลการค้นหา</h3>
            <p>ไม่พบหมวดหมู่ที่ตรงกับ "${query}"</p>
            <button class="auth-btn" onclick="location.reload()">แสดงหมวดหมู่ทั้งหมด</button>
        `;
        
        container.appendChild(emptyState);
    }
}

// Initialize categories page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CategoriesPage();
});